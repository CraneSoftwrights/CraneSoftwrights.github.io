The "dmarcotte" XSLStyle(TM) shell
---------------------------------

With many thanks to Dominic Marcotte <d.marcotte@usherbrooke.ca> for having
prototyped his desired rendering for stylesheets, Crane Softwrights Ltd.
is pleased to include his ideas implemented here as part of the package.

Note that when the top-level <xs:doc> element of the stylesheet being
documented does not have an external-css= stylesheet, this environment will
hard-wire an absolute URI to the known location of this file.  In order to
avoid having an absolute URI to the CSS stylesheet, use the external-css=
attribute.

XSLStyle(TM) by Crane Softwrights Ltd:

  http://www.CraneSoftwrights.com/resources/#xslstyle

=============
$Id: readme.txt,v 1.2 2010/03/02 15:43:38 gkholman Exp $
