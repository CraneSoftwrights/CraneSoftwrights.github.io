This docbook/ directory is part of XSLStyle(TM), a free developer 
resource from Crane Softwrights Ltd.:

  http:www.CraneSoftwrights.com/links/res-xs.htm

This is a copy of selected files and directories from the 
version 1.74.0 June 2008 stylesheets

  http://docbook.sourceforge.net/
  http://sourceforge.net/project/showfiles.php?group_id=21935

2008-10-13 16:30z
