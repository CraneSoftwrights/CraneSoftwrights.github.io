This dita/ directory is part of XSLStyle(TM), a free developer 
resource from Crane Softwrights Ltd.:

  http:www.CraneSoftwrights.com/links/res-xs.htm

This is a copy of selected files and directories from the 
December 2006 DITA Open Toolkit 1.3.1:

  http://sourceforge.net/project/showfiles.php?group_id=132728

Two files have been modified to get around bugs in Internet
Explorer 6.0.2900.2180.xpsp_sp2_gdr.070227-2254 regarding the
document function, and are documented therein:

  common/dita-utilities.xsl
  common/output-message.xsl

The toolkit version 1.4 cannot yet be used due to an undiagnosed
bug in Internet Explorer not recognizing EXSLT extensions where
Saxon doesn't complain.

2007-09-16 20:30:00z