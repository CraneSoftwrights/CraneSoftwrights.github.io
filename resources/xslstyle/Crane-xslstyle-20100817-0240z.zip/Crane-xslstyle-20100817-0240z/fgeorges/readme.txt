The "fgeorges" XSLStyle(TM) shell
---------------------------------

With many thanks to Florent Georges <fgeorges@fgeorges.org> for having
prototyped his desired rendering for stylesheets, Crane Softwrights Ltd.
is pleased to include his ideas implemented here as part of the package.

Many thanks also to George Christian Bina <george@oxygenxml.com> for 
generously giving Crane written permission to use the oXygen XML icon images
as part of the rendering.

Note that when the top-level <xs:doc> element of the stylesheet being
documented does not have an external-css= stylesheet, this environment will
hard-wire an absolute URI to the known location of this file.  In order to
avoid having an absolute URI to the CSS stylesheet, use the external-css=
attribute.

XSLStyle(TM) by Crane Softwrights Ltd:

  http://www.CraneSoftwrights.com/resources/#xslstyle

=============
$Id: readme.txt,v 1.4 2010/03/02 15:43:41 gkholman Exp $
