# Serialize nsgmls output into XML syntax, accommodating SDATA entities,
# NDATA entities, and the document type declaration
#
# $Id: n2x.py,v 1.20 2003/03/01 02:33:04 G. Ken Holman Exp $

usage = \
"""
Arguments: {options} {filename}

Options:   -  = use stdin (also true if the filename is absent)
           -? = print help
           -noi or -nointernal = suppress the internal declaration subset
           -non or -nonotation = suppress notation declarations
           -noe or -noerrors = suppress errors for NDATA entity references
           -nos or -noSDATA = suppress sdata entity replacement
           -nop or -noPI = suppress processing instruction preservation
           -l or -lower = ignore SGML declaration and use lower case for all
                          element type and attribute names and non-CDATA
                          attribute values
           -p:public-id or -public:public-id or "-p:public-id with spaces"
           -s:system-id or -system:system-id or "-s:system-id with spaces"

Assumes:   - spaces are not significant in SDATA entity references

Input:     - the output from the nsgmls tool found at http://www.jclark.com/sp

IMPORTANT: - the "-bUTF-8" runtime option must be specified for nsgmls

Example:   nsgmls -bUTF-8 &lt;test.sgm >test.nsgmls
           python n2x.py &lt;test.nsmgls >test.xml

Note:      - the options "-noi -nos -noe" reproduces the output from SX

"""
"""
 The nsgmls application reads SGML files and returns the ESIS (Element
 Structure Information Set).  The first character of each line is a
 command, documented "sgmlsout.htm" in the http://www.jclark.com/sp
 download package.

 Note that the following NSGMLS commands are not supported; if your SGML
 file triggers any of these commands, they will be ignored:

  "D" - data attribute for external entity
  "&" - reference to an external data entity
  "a" - link attributes
  "I" - reference to an internal data entity
  "T" - reference to an external SGML text entity
  "\#" - APPINFO parameter

 This program appears to work properly only when running the Python
 interpreter explicitly and not when implicitly run through file
 extension association.

Copyright (C) - Crane Softwrights Ltd. - http://www.CraneSoftwrights.com

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, 
  this list of conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, 
  this list of conditions and the following disclaimer in the documentation 
  and/or other materials provided with the distribution. 
- The name of the author may not be used to endorse or promote products 
  derived from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN 
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2002-12-16 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

"""
    
import sys
import re
import sdata

false = 0
true = not(false)
#                                 # initial assumptions
needDoctype = false               # no DOCTYPE is required
doctypePublic = ""
doctypeSystem = ""
showNDATAErrors = true            # report need for NDATA without declaration
includeNotations = true           # assume notation declarations are required
includeSDATA = true               # assume SDATA substitutions are desired
useLowerCase = false              # user may want to ignore SGML declaration
keepPIs = true                    # user may want them suppressed

#=============================================================================#
#
# Command line processing

filename = "-"
stdin = false
internal = true
for arg in sys.argv[1:]:
    if arg[0] == '-':
        value = arg[1:]
        argsplit = re.split( ':', value, 1 )
        if value == 'noi' or value == 'nointernal':
            internal = false
        elif value == '' or value == 'stdin':
            stdin = true
        elif argsplit[0] == 'p' or argsplit[0] =='public':
            doctypePublic = argsplit[1]
            needDoctype = true
        elif argsplit[0] == 's' or argsplit[0] =='system':
            doctypeSystem = argsplit[1]
            needDoctype = true
        elif argsplit[0] == 'e' or argsplit[0] =='entities':
            entityFile = argsplit[1]
        elif value == "non" or value == "nonotation":
            includeNotations = false
        elif value == "noe" or value == "noerrors":
            showNDATAErrors = false
        elif value == "nos" or value == "noSDATA" or value == "nosdata":
            includeSDATA = false
        elif value == "l" or value == "lower":
            useLowerCase = true
        elif value == "nop" or value == "noPI" or value == "nopi":
            keepPIs = false
        elif value=='?':
            sys.stderr.write( usage )
            sys.exit()
        else:
            sys.stderr.write( "Unrecognized switch: "+value+"\n" )
            sys.exit( 1 )
    else:
        if stdin or filename != "-":
            sys.stderr.write( "Only one filename can be given\n" )
            sys.exit( 1 )
        filename = arg

if doctypePublic != "" and doctypeSystem == "":
    sys.stderr.write( "Cannot have public identifier without "+
                      "system identifier" )
    sys.exit( 1 )

nsgmlsFile = sys.stdin
if filename != "-":
    nsgmlsFile = open( filename )
    
#=============================================================================#
#
# Check a string of text for presence of markup and SDATA entity references

def escapeString( s, inAttr ):
    skip = false
    for c in s:
        if skip:
            skip = false
            if c == 'n': sys.stdout.write( '\n' )
            else: sys.stdout.write( c )
        elif c == '<': sys.stdout.write( '&lt;' )
        elif c == '>': sys.stdout.write( '&gt;' )
        elif c == '&': sys.stdout.write( '&amp;' )
        elif inAttr and c == '"': sys.stdout.write( '&quot;' )
        elif c == "\\": skip = true
        else: sys.stdout.write( c )

def escapeText( t, inAttr ):
    components = re.split( "(\\\\\|)", t, 2 )
    escapeString( components[0], inAttr )
    if len(components) == 5: # must have an SDATA entity therein
        components[2] = re.sub( "\s", "", components[2] )
        if includeSDATA:
            if sdata.defs.has_key( components[2] ):
                sys.stdout.write( sdata.defs[ components[2] ] )
            else:
                sys.stderr.write( "SDATA entity not defined: "+components[2]+
                                  "\n")
        else:
            sys.stdout.write( "&"+re.sub( "(\\[|])","",components[2] )+";" )
        escapeText( components[4], inAttr )

#=============================================================================#
#
# Write out the prologue of the XML file

sys.stdout.write( '<?xml version="1.0"?>\n' )

waitDoctype = true

def startDoctype():      # start the document type declaration if necessary
    global waitDoctype
    if waitDoctype:
        sys.stdout.write( '<!DOCTYPE '+documentElement )
        if doctypePublic != "":
            sys.stdout.write( ' PUBLIC "'+doctypePublic+'" "'+
                              doctypeSystem+'"' )
        elif doctypeSystem != "":
            sys.stdout.write( ' SYSTEM "'+doctypeSystem+'"' )
        sys.stdout.write( ' [\n' )
        waitDoctype = false;

def endDoctype():        # finish up the document type declaration if necessary
    if not waitDoctype:
        sys.stdout.write( ']>\n' )

if internal or needDoctype:    # check file for NDATA entities
    entity = ""
    public = ""
    waitDocumentElement = true
    while 1:
        textIn = nsgmlsFile.readline()
        if len(textIn)==0: break
        cmd = textIn[ 0 ]
        if   cmd == 'p':
            public = textIn[ 1:-1 ]
        elif cmd == 'N':
            if includeNotations:
                startDoctype()
                sys.stdout.write( '<!NOTATION '+textIn[ 1:-1 ] )
                if public != "":
                    sys.stdout.write( ' PUBLIC "'+public+'" "">\n' )
                    public = ""
                else:
                    sys.stdout.write( ' SYSTEM "">\n' )
        elif cmd == 's': entitySystem = textIn[ 1:-1 ]
        elif cmd == 'f': pass
        elif cmd == 'E':
            if internal:
                entityInfo = re.split( '\s', textIn[ 1:-1 ], 2 )
                if entityInfo[1] == 'NDATA':
                    startDoctype()
                    sys.stdout.write( '<!ENTITY '+
                                      entityInfo[ 0 ]+
                                      ' SYSTEM "'+entitySystem+'" '+
                                      entityInfo[ 1 ]+' '+
                                      entityInfo[ 2 ]+'>\n')
                entitySystem = ""
        elif waitDocumentElement and cmd == "(":
            waitDocumentElement = false
            documentElement = textIn[ 1:-1 ]
            if useLowerCase:
                documentElement = documentElement.lower()
            if needDoctype:
                startDoctype()
        elif cmd == 'C':
            break;
        elif cmd in [ '(', ')', '?', 'A', '-', 'i', 'L',
                      'E', 'S', '{', '}', '#', 'e' ]:
            pass
        else:
            raise( "Unsupported cmd: "+cmd )
    nsgmlsFile.seek( 0 ) # restart

endDoctype()

#=============================================================================#
#
# Convert the NSGMLS format to XML syntax
#
# note below that code is duplicated in a number of places instead of bringing
# out common fragments into new variable assignments; this is thought to
# improve the performance

attrs = []
while 1:
    textIn = nsgmlsFile.readline()
    if len(textIn)==0: break
    cmd = textIn[ 0 ]
    if   cmd == '-': escapeText( textIn[ 1:-1 ], false )
    elif cmd == "(":
        if useLowerCase:
            sys.stdout.write( "<"+textIn[ 1:-1 ].lower()+"\n" )
        else:
            sys.stdout.write( "<"+textIn[ 1:-1 ]        +"\n" )
        for a in attrs:
            if useLowerCase:
                sys.stdout.write( a[0].lower()+'="' )
            else:
                sys.stdout.write( a[0]        +'="' )
            if a[1] == 'CDATA' or not(useLowerCase):
                escapeText( a[2]        , true )
            else:
                escapeText( a[2].lower(), true )
            sys.stdout.write( '"\n' )
        attrs = []
        sys.stdout.write( ">" )
    elif cmd == ")":
        if useLowerCase:
            sys.stdout.write( "</"+textIn[ 1:-1 ].lower()+">" )
        else:
            sys.stdout.write( "</"+textIn[ 1:-1 ]        +">" )
    elif cmd == "?":
        if keepPIs:
            sys.stdout.write( "<?"+textIn[ 1:-1 ]+"?>" )
    elif cmd == "A":
        newAttr = re.split('\s', textIn[ 1:-1 ], 2)
        if len(newAttr) == 3:
            attrs = attrs + [ newAttr ];
    elif cmd == "C":
        sys.stdout.write( "\n" )
        break;
    elif not(internal) and cmd == 'E':
        if showNDATAErrors:
            sys.stderr.write( "Error: Unparsed entity reference encountered "+
                              "with no internal declaration subset")
    elif cmd in [ 'p', 'N', 's', 'f', 'i', 'L',
                  'E', 'S', '{', '}', '#', 'e' ]:          
        pass

# end of file
