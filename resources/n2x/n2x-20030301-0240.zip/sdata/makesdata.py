# Make the "sdata.py" import file for nsgmls2xml.py
#
# $Id: makesdata.py,v 1.9 2003/03/01 00:14:05 G. Ken Holman Exp $

usage = """
Usage:  [-opt]* filename

 -x            = example
 -y arg        = example
"""

"""
 The input may be the standard input or supplied file names that
 are assumed to be the same format as:
 
  <sdata ref="Aacgr" set="ISOgrk2" code="0386">GREEK CAPITAL ... TONOS</sdata>
  <sdata ref="aacgr" set="ISOgrk2" code="03AC">GREEK SMALL ... TONOS</sdata>

 The output is a Python dictionary declaration indexed by entity name.
 
 Multiple definitions for the same entity name may be supplied, only the
 last one is used in the output XML.

Copyright (C) - Crane Softwrights Ltd. - http://www.CraneSoftwrights.com

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, 
  this list of conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, 
  this list of conditions and the following disclaimer in the documentation 
  and/or other materials provided with the distribution. 
- The name of the author may not be used to endorse or promote products 
  derived from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN 
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2002-12-16 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

"""

import sys
import re
import string
import fileinput
from xml.sax import parse, SAXParseException
from xml.sax.handler import ContentHandler

false = 0
true = not( false )
codeSet = {}

def errorExit( str ):
    sys.stderr.write( str )
    sys.exit( 1 )

#=========================================================================
#
# Argument processing

badopt = false
while len( sys.argv ) > 1 and \
      ( sys.argv[1][0] == '/' or sys.argv[1][0] == '-' ):
    opt = sys.argv[1][1:]
    if opt == '?':
        print usage
        sys.exit( 0 )
    else:
        print( 'Option "%s" not recognized' % opt )
        badopt = true
    sys.argv[ 1:2 ] = [] # remove argument

if badopt: # cannot proceed as requested by user
    sys.stderr.write( usage )
    sys.exit(1)

if len( sys.argv ) == 1:
    sys.argv[ 1:2 ] = [ "<stdin>" ]
    
#=========================================================================
#
# Input processing

    # Handle an event and pass on for further events
class myHandler( ContentHandler ):
    def startElement( this, name, attrs):
        if name == "sdata":
            ref = ""
            code = ""
            for ( attr, value ) in attrs.items():
                if attr == "ref": ref = value
                elif attr == "code": code = value
            codeSet[ ref ] = code
        ContentHandler.startElement( this, name, attrs )

handler = myHandler()

for fileInName in sys.argv[ 1: ]:
    global fileIn
    if fileInName == "<stdin>":
        fileIn = sys.stdin
    else:
        try: # opening the input file
            fileIn = open( fileInName, "r" )
        except IOError, (errno, strerror):
            sys.stderr.write( "I/O error(%s): %s" % (errno, strerror) )
            sys.exit(1)
    try: # processing the input file using the defined SAX events
        parse( fileIn, handler )
    except IOError, (errno, strerror):
        errorExit( "I/O error(%s): %s: %s" % (errno, strerror, fileInName) )
    except SAXParseException:
        errorExit( "File does not parse as well-formed XML: %s" % fileInName )

#=========================================================================
#
# Output processing

sys.stdout.write( '# automatically generated Python source\n\n'+
                  'defs = {\n"":""' )

codeSetSorted = []
for name in codeSet.keys():
    codeSetSorted.append( name )
codeSetSorted.sort()

for name in codeSetSorted:
    sys.stdout.write( ',\n"%s":"&#x' % name )
    sys.stdout.write( string.join( re.split( ";", codeSet[ name ] ), ";&#x" ) )
    sys.stdout.write( ';"' )

sys.stdout.write( '\n}\n\n#end of file\n' )

# end of file
