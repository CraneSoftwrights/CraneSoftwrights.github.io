Various acid files for testing XML, XSLT and XSL-FO processors:

(1) check acid.xml for well-formedness:

  - uses acid.ent for external declaration subset
  - one entity is a simple string, the other has markup
  - the test works if no errors are reported

(2) check aciddtd.xml for validity:

  - the test works if no errors are reported

(3) process acid.xml with acid-fo.xsl to produce an output XSL-FO file:

  - uses acid-fo.ent for external declaration subset
  - the test works if no errors are reported

(4) process hellofo.xml with hellofo-bad.xsl 

  - the stylesheet file is not well-formed
  - the test works if the only report is a problem with the name in
    an end tag; the test fails if anything else is reported as wrong

(5) check acidns.xsl for well-formedness:

  - the test works if no errors are reported

========================================================================
$Id: readme.txt,v 1.3 2003/07/30 19:47:01 G. Ken Holman Exp $