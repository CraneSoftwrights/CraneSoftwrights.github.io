# Extract all possible xpath paths and synthesize an instance
#
# $Id: xpathall.py,v 1.9 2003/07/26 22:25:37 G. Ken Holman Exp $

"""
Copyright (C) - Crane Softwrights Ltd.
              - http://www.CraneSoftwrights.com/links/res-lxslts.htm

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, 
  this list of conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, 
  this list of conditions and the following disclaimer in the documentation 
  and/or other materials provided with the distribution. 
- The name of the author may not be used to endorse or promote products 
  derived from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN 
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2003-07-26 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5
"""

from xml.sax import parse, SAXParseException
from xml.sax.xmlreader import AttributesImpl
from xml.sax.handler import ContentHandler
from xml.sax.saxutils import XMLGenerator
import sys
import re
import string
false = 0
true = not( false )

pathlocs = []
errorPaths = []
debug = 0

def exit( reason=None ): #all error exits should have a reason to display
    if reason:
        sys.stderr.write( "%s\n" % reason )
        sys.stderr.write( "Aborted exit...\n" )
        sys.exit(1)
    sys.exit(0)

class myHandler( ContentHandler ):
    def startElement( this, name, attrs):
        global pathlocs
        path = ""
        location = ""
        for ( attr, value ) in attrs.items():
            if attr == "path": #found a path that needs to be normalized
                path = re.sub( ' ', '', value )
            elif attr == "loc": #found the location for the path
                location = value
        pathlocs = pathlocs + [ ( path, location ) ]
        ContentHandler.startElement( this, name, attrs )

handles = myHandler()

#=============================================================================
#
# Input logic

try: # processing the input file using the defined SAX events
    parse( sys.stdin, handles )
except IOError, (errno, strerror):
    exit( "I/O error(%s): %s: %s" % (errno, strerror, file) )
except SAXParseException:
    exit( "File does not parse as well-formed XML: %s" % file )

expanded = []

# add as many strings as necessary to the list of expanded XPath strings
def addExpanded( before, after, loc, depth=0 ):
    global expanded
    depth = depth + 1
    if debug: print "Expanding(%d): '%s' and '%s'" % ( depth, before, after )
    left = ""
    this = ""
    skip = false
    level = 0
    waitingUnion = false
    for i in range( len( after ) ): # walk through the input string
        c = after[i]
        if skip:
            skip = false
        elif level > 0:               # in the process of eating bracketed
            if c == ']' or c == ')':# on level less in the bracketed
                level = level - 1
                if level < 0:
                    break;
            elif c == '[' or c == '(': # one level more in the bracketed
                level = level + 1
            else:                   # still eating bracketed
                if debug: print "Skipping(%d): %s (%d)" % ( depth, c, level )
        elif c == '|':              # union
            addExpanded( before, after[ i+1: ], loc, depth )
            level = 1               # skip until end of union
        elif c == '/':              # at a new step, remember to the left
            this = this+'/'
            left = this
        elif c in [ ',', "'", '"' ]:
            return # no need to look at function arguments or strings
        elif c == '(':              # in a function; process content only
            level = level + 1
            addExpanded( before+left, after[ i+1: ], loc, depth )
            return # no need to look at remainder: a function isn't a step
        elif c == '[':              # in a predicate
            level = level + 1
            addExpanded( before+after[:i]+'/' , after[ i+1: ], loc, depth )
        elif c == ']':              # anything past this is a lower level
            return
        elif c == ')':              # anything past might be another step
            break;
        else:                       # just another character
            if this== '' and c >= '0' and c <= '9':
                return #must be a number because names can't start with digits
            this = this+c           # just another character of a name
    if debug: print "Adding(%d): '%s'+'%s'" % ( depth,before,this )
    expanded = expanded + [ ( before+this, loc ) ]

for ( path, location ) in pathlocs: # expand each of the found paths
    if debug: print "Path: "+path
    addExpanded( '', path, location )

#=============================================================================
#
# Path reduction

reduced = {}

# create a nested dictionary of dictionaries of dictionaries, one per level
def addReduced( steps, current, location ):
    if not( current.has_key( steps[0] ) ):
        current[ steps[0] ] = {}
    if len( steps ) > 1:
        addReduced( steps[1:], current[ steps[0] ], location )
    else:
        current[ "" ] = location

# add all of the expanded paths to the dictionary of dictionaries
for ( path, location ) in expanded:
    if debug: print "Expanded: "+path
    steps = re.split( '/', path )
    if steps[ 0 ] == "": # don't bother adding when there is a root
        steps[ 0 : 1 ] = []
    else:
        print "Found path not starting at root: "+path
    # remove redundant or unexpected steps
    i = 0
    while i < len( steps ):
        step = steps[ i ]
        step = re.sub( "^child::", "", step ) # child axis redundant
        selfStep = re.sub( "^self::", "", step ) # self axis might be like '.'
        if debug: print "Reduce step: "+step

        # can check following or preceding
        axisStep = re.sub( "^(following-sibling::|preceding-sibling::)",
                           '', step )

        if re.search( "^(following::|preceding::|namespace::|descendant::|"+
                        "ancestor::|ancestor-or-self::|descendant-or-self::)",
                      step ):  # cannot look past these 
            steps[ i: ] = []
        elif axisStep != step: # must be sibling, so get rid of self
            steps[ i - 1 : i + 1 ] = [ axisStep ]
            i = i - 1
        elif step == '.' or step == 'self::*': # no movement 
            steps[ i : i + 1 ] = []
        elif selfStep != step: # nonsensical but possible
            steps[ i - 1 : i + 1 ] = [ selfStep ]
            if i == 0: i = -1
        elif step == '..': # go up
            steps[ i - 1 : i + 1 ] = []
            i = i - 1
        else: # keep going down
            i = i + 1

        if i < 0: # attempted to go above the root
            steps = []
            errorPaths = errorPaths + [ path ]
            break

    if debug: print "Reduce steps: ",
    if debug: print steps
#    for i in range( len( steps ) ):
#        steps[ i ] = re.sub( '^[^:]+:', '', steps[ i ] ) #extract any prefix

    # if anything left, add it to the reduced list
    if len( steps ):
        addReduced( steps, reduced, location )

#=============================================================================
#
# Output logic

def outReduced( current, level=0 ):
    level = level + 1
    for step in current.keys():
        if len( step ) > 0:
            indent = ""
            for i in range( level ):
                indent = indent + "  "
            location = ""
            if current.has_key( "" ):
                location = ' loc="%s"' % current[ "" ]
            if step[ 0 ] == '@':
                print indent+'<a n="%s"%s/>' % ( step[1:], location )
            else:
                print indent+'<e n="%s"%s>' % ( step, location )
                outReduced( current[ step ], level )
                print indent+'</e>'

if len( errorPaths ) > 0:
    print 
    for path in errorPaths:
        print path
    exit( "Problem paths preventing continuation:\n"+
          string.join( errorPaths,'\n' )+
          "Cannot continue" )
else:
    # trigger serialization
    print "<paths>"
    outReduced( reduced )
    print "</paths>"

# end of file
