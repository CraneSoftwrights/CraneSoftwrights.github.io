# A program to dump the character contents of a file using XSL-FO
# for the formatting.  Formatted output goes to stdout.
#
# $Id: dumpfo.py,v 1.19 2002/11/12 19:31:20 G. Ken Holman Exp $

usage = """
Usage:  [-opt]* filename

 -lf           = act on linefeed as well as interpret linefeed
 -a4           = A4 page size
 -a4l          = A4 landscape page size (default)
 -us           = US letter page size
 -usl          = US letter landscape page size
 -e {encoding} = character encoding system used in the input file
               = default: Latin1
               = other typical values: utf-8, utf-16, utf-16-le, utf-16-be
"""
# Still not done:
#
# (1) - printing of decimal and hexadecimal character offsets and line numbers
# (2) - only few abstract Unicode characters are accommodated by their
#       abbreviated name and many more could probably be added

# Abstract and control characters:
#
# The following maps C0 control characters (except for using space for "NUL")
# and Unicode abbreviated names for characters (many are missing); note that
# 4-character names are split using a dash because the formatting is better
# suited to 2-character and 3-character names (the dash triggers a line break)

xlate = { 0x0000:" ",     0x0001:"SOH",   0x0002:"STX",   0x0003:"ETX",
          0x0004:"EOT",   0x0005:"ENQ",   0x0006:"ACK",   0x0007:"BEL",
          0x0008:"BS",    0x0009:"TAB",   0x000a:"LF",    0x000b:"VT",
          0x000c:"FF",    0x000d:"CR",    0x000e:"SO",    0x000f:"SI",
          0x0010:"DLE",   0x0011:"DC1",   0x0012:"DC2",   0x0013:"DC3",
          0x0014:"DC4",   0x0015:"NAK",   0x0016:"SYN",   0x0017:"ETB",
          0x0018:"CAN",   0x0019:"EM",    0x001a:"SUB",   0x001b:"ESC",
          0x001c:"FS",    0x001d:"GS",    0x001e:"RS",    0x001f:"US",
          0x200e:"LRM",   0x200f:"RLM",   0x200d:"ZWJ",   0x200c:"ZW-NJ",
          0x202a:"LRE",   0x202b:"RLE",   0x202d:"LRO",   0x202e:"RLO",
          0x202c:"PDF",   0x206e:"NA-DS", 0x206f:"NO-DS",  
          0x206b:"ASS",   0x206a:"ISS",   0x206d:"AA-FS", 0x206c:"IA-FS",
          0xfeff:"BOM" }

import sys
import codecs
false = 0
true = not( false )

lf = false
badopt = false
dohex = false
width = "297mm"
height = "210mm"
encoding = "Latin1"

#=========================================================================
#
# Argument processing

while len( sys.argv ) > 1 and \
      ( sys.argv[1][0] == '/' or sys.argv[1][0] == '-' ):
    opt = sys.argv[1][1:]
    if opt == 'lf':  lf = true
    elif opt == 'hex': dohex = true
    elif opt == 'a4':  width="297mm"; height="210mm"
    elif opt == 'a4l': width="210mm"; height="297mm"
    elif opt == 'us':  width="8.5in"; height="11in"
    elif opt == 'usl': width="11in";  height="8.5in"
    elif opt == 'e' or opt == 'encoding' and len( sys.argv ) > 3:
        encoding = sys.argv[2]
        sys.argv[2:3] = []
        try: # finding the requested encoding codec in Python
            codecs.lookup( encoding )
        except LookupError:
            sys.stderr.write( 'Encoding "'+encoding+'" not recognized.' )
            badopt = true
        except:
            sys.stderr.write( "Unexpected error: see output file for details" )
            print sys.exc_info()
            raise
    else:
        print( 'Option "%s" not recognized' % opt )
        badopt = true
    sys.argv[ 1:2 ] = []

if len( sys.argv ) != 2 or badopt: # cannot proceed as requested by user
    sys.stderr.write( usage )
    sys.exit(1)
    
try: # opening the input file
    fileIn = codecs.open( sys.argv[1], "r", encoding )
except IOError, (errno, strerror):
    sys.stderr.write( "I/O error(%s): %s" % (errno, strerror) )
    sys.exit(1)
except:
    sys.stderr.write( "Unexpected error: see output file for details" )
    print sys.exc_info()[0]
    sys.exit(1)

#=========================================================================
#
# Output generation

print """<?xml version="1.0" encoding="utf-8"?><!--dumpfo.fo-->
<!DOCTYPE root [
  <!ENTITY dumpfo.txt SYSTEM "dumpfo.txt">
]>
<root xmlns="http://www.w3.org/1999/XSL/Format">

  <layout-master-set>
    <simple-page-master master-name="frame" 
                        page-height="%s" page-width="%s" 
                        margin-top="%s" margin-bottom="%s" 
                        margin-left="%s" margin-right="%s">
      <region-body region-name="frame-body"/>
    </simple-page-master>
  </layout-master-set>
  
  <page-sequence master-reference="frame">
    <flow flow-name="frame-body" font-family="Courier" font-size="4pt">
    <block linefeed-treatment="preserve" white-space-collapse="false">
""" % ( height, width, "1cm", "1cm", "1cm", "1cm" )

# character processing

def do_char( c ): # "c" is the character and "cord" is its ordinal int
    if c == "": cord = 0xfeff
    else: cord = ord( c )
    
    print '<inline-container height="5em" text-align="center">' \
          '<block font-size="4em" line-height="1">'

    # display the character in its readable form
    if xlate.has_key( cord ): #then this signal is known to this program
        print '<inline-container reference-orientation="90deg" ' \
              'width=".9em" line-height="1" ' \
              'display-align="center" alignment-adjust="after-edge">' \
              '<block font-size="45%" text-align="center" line-height="1">'+ \
              xlate[ cord ]+ '</block></inline-container>'
    elif c == "<": print "&lt;" # protected markup for XSL-FO XML
    elif c == "&": print "&amp;" # protected markup for XSL-FO XML
    else:
        print unichr( cord ).encode( 'utf8' ) # XML needs UTF-8 encoding

    # print the hexadecimal sequence of the character
    print '</block><block>'+("000"+hex(cord)[2:])[-4:]+'</block>' \
          '</inline-container>',

    if c == "\n" and lf: print "\n" # user wants new lines to be seen

# file processing

BOM = false
first = true
while 1:
    try: # reading the next character of the file
        c = fileIn.read( 1 )
    except UnicodeError:
        sys.stderr.write( "Encoding error for "+encoding )
        print '<inline font-size="4em">ERROR: '+encoding+'</inline>'
        break;
    except:
        sys.stderr.write( "Unexpected error: see output file for details" )
        print sys.exc_info()[0]
        sys.exit(1)

    if c == "": # might be end of file or might be a BOM
        if first: # the first character is ambiguous because of BOM
            BOM = true # assume for now a BOM, but only if followed
            first = false # stop looking for BOM
        else: break; # reached the end of the input file
    else: # a meaningful character
        if BOM: do_char( "" ); BOM = false # must have had a BOM
        do_char( c ) # put out the character
        
print """
      </block>
    </flow>
  </page-sequence>
</root>
"""

# end of file
