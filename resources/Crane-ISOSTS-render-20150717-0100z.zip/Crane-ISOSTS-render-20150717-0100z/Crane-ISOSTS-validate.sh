DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

echo Validating with the full ISOSTS document model...

java 2>&1 -jar $DIR/jar/jing/bin/jing.jar $DIR/rng/ISOSTS.rng $1
if [ $? -ne 0 ]
then
exit 1
fi

echo Confirming the ISOSTS constraints on the full model...

java 2>&1 -jar $DIR/jar/saxon9he/saxon9he.jar -xsl:$DIR/Crane-ISOSTS_validation-1.1.xsl -s:$1
if [ $? -ne 0 ]
then
exit 1
fi
