if [ "a$1" == "a" ]
then
echo  This is a drag-and-drop-compatible shell script taking as input a single
echo  argument being an XML file to validate against ISOSTS constraints and
echo  then produce A4-sized PDF from the XML by using Antenna House.
echo
echo  The PDF results are placed in a PDF file in the same directory as the XML
echo  file, with the file extension \".pdf\". The execution reports are placed
echo  in a text file in the same directory as the XML file, with the file
echo  extension \".pdf.txt\".
exit 1
fi

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

sh $DIR/ahf-a4-pdf.sh $1 us
