if [ "a$1" == "a" ]
then
echo  This is a drag-and-drop-compatible shell script taking as input a single
echo  argument being an XML file to validate against ISOSTS constraints and
echo  then produce A4-sized PDF from the XML by using Ibex.
echo
echo  The PDF results are placed in a PDF file in the same directory as the XML
echo  file, with the file extension \".pdf\". The execution reports are placed
echo  in a text file in the same directory as the XML file, with the file
echo  extension \".pdf.txt\".
exit 1
fi

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

fullpath=$1
filename="${fullpath##*/}"                      # Strip longest match of */ from start
dir="${fullpath:0:${#fullpath} - ${#filename}}" # Substring from 0 thru pos of filename
base="${filename%.[^.]*}"                       # Strip shortest match of . plus at least one non-dot char from end
ext="${filename:${#base} + 1}"                  # Substring from len of base thru end
if [[ -z "$base" && -n "$ext" ]]; then          # If we have an extension and no base, it's really the base
    base=".$ext"
    ext=""
fi

DPN1=$dir$base

echo Invoking: $DIR../ibex/Crane-isosts2pdf4ibex.sh
echo Errors to: $DPN1.pdf.txt
echo Working...

if [ "a$2" == "aus" ]
then
{ time sh $DIR/../ibex/Crane-isosts2pdf4ibex.sh 2>&1 >$DPN1.pdf.txt $1 us $DPN1.pdf ; } 2>>$DPN1.pdf.txt
else
{ time sh $DIR/../ibex/Crane-isosts2pdf4ibex.sh 2>&1 >$DPN1.pdf.txt $1 a4 $DPN1.pdf ; } 2>>$DPN1.pdf.txt
fi
if [ $? -ne 0 ]
then
cat $DPN1.pdf.txt
echo The above errors are copied to: $DPN1.pdf.txt
exit 1
fi

open $DPN1.pdf
