if [ "a$1" == "a" ]
then
echo  This is a drag-and-drop-compatible shell script taking as input a single
echo  argument being an XML file to validate against ISOSTS constraints.  The
echo  validation results are placed in a text file in the same directory as
echo  the XML file, with the file extension ".validate.txt"
exit 1
fi

DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

echo Working...
{ time sh $DIR/../Crane-ISOSTS-validate.sh $1 2>&1 >$1.validate.txt ; } 2>>$1.validate.txt
if [ $? -ne 0 ]
then
cat $1.validate.txt
echo The above errors are copied to: $1.validate.txt
exit 1
fi

echo Successful validate \(Report below copied to: $1.validate.txt\)
cat $1.validate.txt
