echo Invoking Antenna House Formatter: $1\(.xml\) with $2\(us/a4\) to $3\(.pdf\)
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

if [ ! -f $DIR/../jar/saxon9he/saxon9he.jar ]
then
echo Cannot find $DIR/../jar/saxon9he/saxon9he.jar version 9 \(Home Edition\) from: 
echo http://saxon.sourceforge.net/
exit 1
fi

if [ ! -f $1 ]
then
echo Unable to find: $1
exit 1
fi

if [ "a$3" == "a" ]
then
echo Output file not specified for third argument
exit 1
fi

if [ "a$2" != "aa4" -a "a$2" != "aus" ]
then
echo Unrecognized page file format: $2
exit 1
fi

rm -f $3

sh $DIR/../Crane-ISOSTS-validate.sh $1
if [ $? -ne 0 ]
then
exit 1
fi

echo Transforming XML to XSL-FO using Saxon 9\(HE\)...
java 2>&1 -jar $DIR/../jar/saxon9he/saxon9he.jar -o:$1.fo -s:$1 -xsl:$DIR/../Crane-isosts2fo-$2.xsl $4 $5 $6 $7 $8 $9
if [ $? -ne 0 ]
then
exit 1
fi

echo Transforming XML to PDF using Antenna House...
ahfcmd 2>&1 -d $1.fo -o $3 -i $DIR/ahf-config.xml
if [ $? -ne 0 ]
then
exit 1
fi

echo Success!
