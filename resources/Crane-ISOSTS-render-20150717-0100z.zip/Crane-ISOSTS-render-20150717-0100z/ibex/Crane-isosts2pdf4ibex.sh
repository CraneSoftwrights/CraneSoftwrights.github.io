echo Invoking Ibex formatter: $1\(.xml\) with $2\(us/a4\) to $3\(.pdf\)
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

if [ ! -f $DIR/../jar/saxon9he/saxon9he.jar ]
then
echo Cannot find $DIR/../jar/saxon9he/saxon9he.jar version 9 \(Home Edition\) from: 
echo http://saxon.sourceforge.net/
exit 1
fi

if [ ! -f $DIR/../jar/ibex/ibex-crane-ss.jar ]
then
echo Cannot find $DIR/../jar/ibex/ibex-crane-ss.jar from: 
echo http://www.xmlpdf.com/ibex-downloads-signed.html
exit 1
fi

if [ ! -f $DIR/Crane-isosts2fo-manifest.xml ]
then
echo Unable to find $DIR/Crane-isosts2fo-manifest.xml
exit 1
fi

if [ ! -f $1 ]
then
echo Unable to find: $1
exit 1
fi

if [ "a$3" == "a" ]
then
echo Output file not specified for third argument
exit 1
fi

if [ "a$2" != "aa4" -a "a$2" != "aus" ]
then
echo Unrecognized page file format: $2
exit 1
fi

rm -f $3

sh $DIR/../Crane-ISOSTS-validate.sh $1
if [ $? -ne 0 ]
then
exit 1
fi

echo Transforming XML to XSL-FO using Saxon 9\(HE\)...
java 2>&1 -jar $DIR/../jar/saxon9he/saxon9he.jar -o:$1.fo -s:$1 -xsl:$DIR/../Crane-isosts2fo-$2.xsl $4 $5 $6 $7 $8 $9
if [ $? -ne 0 ]
then
exit 1
fi

echo Transforming XML to PDF using Ibex...
java 2>&1 -cp $DIR/../jar/saxon9he/saxon9he.jar:$DIR/../jar/ibex/ibex.jar:$DIR/../jar/ibex/ibex-crane-ss.jar -Djavax.xml.transform.TransformerFactory=net.sf.saxon.TransformerFactoryImpl -Dibexconfig=$DIR/Crane-isosts-ibexconfig-sh.xml ibex.Signed -xml $1 -xsl $DIR/Crane-isosts2fo-$2-ibex.xsl -manifest $DIR/Crane-isosts2fo-manifest.xml -pdf $3
if [ $? -ne 0 ]
then
exit 1
fi

echo Success!
