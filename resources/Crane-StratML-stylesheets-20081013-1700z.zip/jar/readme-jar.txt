This "jar" directory is the home of ".jar" files obtained by the end user:

For HTML:

 saxon9.jar from: http://saxon.sf.net

For PDF:

 saxon9.jar from: http://saxon.sf.net
 ibex-crane-ss-x.y.z.jar from: http://www.xmlpdf.com/ibex-downloads-signed.html

Without these files the invocation batch files will not run and will
request these files be obtained.

====================================
$Id$
