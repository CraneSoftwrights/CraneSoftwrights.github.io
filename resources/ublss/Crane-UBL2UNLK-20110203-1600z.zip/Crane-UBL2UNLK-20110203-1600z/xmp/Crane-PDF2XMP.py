usage = """
 Read a PDF file on standard input and put the first embedded XMP packet
 out to the standard output:

   python Crane-PDF2XMP.py <j.pdf >j.xmp

"""
# $Id: Crane-PDF2XMP.py,v 1.5 2011/01/29 18:40:16 admin Exp $
"""
Copyright (C) - Crane Softwrights Ltd.
              - http://www.CraneSoftwrights.com/links/res-dev.htm

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
- The name of the author may not be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2003-07-26 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

THE AUTHOR MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS CODE FOR ANY
PURPOSE.
"""

import re
import sys
import platform
if platform.system()=='Windows': # need unbuffered I/O when on Windows
    import msvcrt
    import os
    msvcrt.setmode(sys.stdin.fileno(), os.O_BINARY)
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)

#=========================================================================
#
# Argument processing

badopt = False
while len( sys.argv ) > 1 and \
      ( sys.argv[1][0] == '/' or sys.argv[1][0] == '-' ):
    opt = sys.argv[1][1:]
    if opt == '?' or opt == '-help':
        sys.stderr.write( usage )
        sys.exit( 0 )
    else:
        print( 'Option "%s" not recognized' % opt )
        badopt = True
    sys.argv[ 1:2 ] = [] # remove argument

if sys.stdin.isatty(): # assume user is not going to type in a PDF file
  sys.stderr.write( usage )
  sys.exit( 1 )

# The definition of the start and end of the XMP packet is defined in section
# 7.3.2 XMP packet wrapper of "XMP Specification Part 1: Data Model,
# Serialization and Core Properties" July 2010 found at:
# http://www.adobe.com/content/dam/Adobe/en/devnet/xmp/pdfs/XMPSpecificationPart1.pdf
startPacket=re.compile('<\?xpacket begin=".*" id="W5M0MpCehiHzreSzNTczkc9d"')
endPacket=re.compile('^.*?(<\?xpacket end="(w|r)".*?\?>)')

# Walk through the input until the packet is started

inPacket = False
for each in sys.stdin.readlines():
  if startPacket.match( each ):
    # time to start a packet
    inPacket=True
  # stop when we get to the end of the last packet, putting out only the packet
  # (in case anything past it which would make output XML not well-formed)
  endMatch = endPacket.match( each )
  if endMatch:
    #print >>sys.stderr,endMatch.span(1)[0], endMatch.span(1)[1], "*"+each+"*"
    sys.stdout.write( each[:endMatch.span(1)[1]] ) # write up to last included
    sys.exit(0)
  # write out lines while we are wholly in a packet
  if inPacket: sys.stdout.write( each )

# At this point something is wrong, because it should have stopped above

if inPacket:
  print >>sys.stderr,"The end of the embedded XMP packet is missing"
else:
  print >>sys.stderr,"No XMP packet found in the input"
  
sys.exit(1)

# end of file
