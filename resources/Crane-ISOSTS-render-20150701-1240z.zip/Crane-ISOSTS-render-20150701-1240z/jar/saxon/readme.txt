The JAR file for Saxon 6.5.5 can be found through:

  http://saxon.sourceforge.net/saxon6.5.5/index.html
