The latest signed JAR file can be downloaded from:

  http://www.xmlpdf.com/ibex-downloads-signed.html

... but must be renamed without a version number to be "ibex-crane-ss.jar"

Alternatively, you can use a commercial copy of Ibex or the latest unsigned JAR for evaluation downloaded from:

  http://www.xmlpdf.com/downloads-java.html
  
... but it must be renamed without a version number to be "ibex.jar"
