Demonstration of XSLT-based aggregation
=======================================

aggregation.htm - documentation of the demonstration of aggregation

lic.xml - licensee information
assy.xsl - assembly of aggregated information
sched.xml - structure/content of the synthesized schedule page
sched.xsl - transformation of structure and aggregated schedule information
result-file.xsl - writing of a result file with support for multiple processors

self.xml - own schedule of deliveries
other1.xml - a licensee's schedule of deliveries
other2.xml - a licensee's schedule of deliveries

publ.xsl - publishing of aggregated schedule information into XML

run.bat - invocation of test

backup\readme.txt - placebo used to create necessary backup subdirectory

$Date: 2004/11/14 04:58:17 $(UTC)