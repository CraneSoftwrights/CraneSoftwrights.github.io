Directory of copies of obtained XML documents; for backup purposes
