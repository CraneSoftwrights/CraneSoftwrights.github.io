The JAR file for Saxon HE (Home Edition) can be found at:

  http://saxon.sourceforge.net/#F9.6HE
