# Convert a UBL XPath XML instance into one of various kinds of reports
#
#    <stdin>  = XPath file
#    <stdout> = report output
#
# $Id: xpath2report.py,v 1.5 2007/04/12 20:11:12 G. Ken Holman Exp $
"""
Copyright (C) - Crane Softwrights Ltd. 

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, 
  this list of conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, 
  this list of conditions and the following disclaimer in the documentation 
  and/or other materials provided with the distribution. 
- The name of the author may not be used to endorse or promote products 
  derived from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN 
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2002-12-16 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5
"""

usage = """
Create an XPath report from the contents of an XPath file

Usage:  [-arg]*

Standard input:  XPath file

Standard output:  report file

Mandatory argument (choose one of the following):

 -t{ype} xml  = xml instance report
 -t{ype} html = html report
 -t{ype} text = text report

Optional arguments:

 -m{inimal}   = minimal text report
 -c{opyright} file = copyright file
"""
#=========================================================================
#
# Libraries and global declarations

from xml.sax import make_parser, SAXParseException
from xml.sax.handler import ContentHandler
from xml.sax.xmlreader import AttributesImpl
import sys
import re
import codecs
import string

false = 0
true = not false
result = false
resulttext = false
resulthtml = false
resultxml = false
minimal = false
xpathURI = "urn:oasis:names:tc:ubl:schema:XPath-1.0"

# turn off newline sequence translation in Windows platforms
if sys.platform == "win32":
    import os, msvcrt
    msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)

key = 0 #incrementing unique numeric value

def exit( reason=None ): #all error exits should have a reason to display
    if reason:
        sys.stderr.write( "%s\n" % reason )
        sys.stderr.write( "Aborted exit...\n" )
        sys.exit(1)
    sys.exit(0)

#=========================================================================
#
# Argument processing

badopt = false
copyright = [ ]
while len( sys.argv ) > 1 and \
      ( sys.argv[1][0] == '/' or sys.argv[1][0] == '-' ):
    opt = sys.argv[1][1:]
    if opt == '?' or opt == '-help':
        sys.stderr.write( usage )
        sys.exit( 0 )
    elif ( opt == 'm' or opt == 'minimal' ):
        minimal = true
    elif ( opt == 't' or opt == 'type' ) and len( sys.argv ) >= 2 \
         and not result:
        if sys.argv[2] == 'text': resulttext = true; result = true
        elif sys.argv[2] == 'html': resulthtml = true; result = true
        elif sys.argv[2] == 'xml': resultxml = true; result = true
        else: print( 'Type "%s" not recognized' % sys.argv[2] )
        sys.argv[2:3] = [] # remove argument to argument
    elif ( opt == 'c' or opt == 'copyright' ) and len( sys.argv ) >= 2:
        try:
            c = open( sys.argv[2], 'r' )
            copyright = c.readlines()
            c.close()
        except:
            sys.stderr.write( "Unable to read copyright file: %s\n" % \
                              sys.argv[2] )
            sys.exit( 1 )
        sys.argv[2:3] = [] # remove argument to argument
    else:
        print( 'Option "%s" not recognized' % opt )
        badopt = true
    sys.argv[ 1:2 ] = [] # remove argument

if len( sys.argv ) != 1 or badopt or not result: # cannot proceed
    sys.stderr.write( usage )
    sys.exit(1)

#=========================================================================
#
# HTML support routines

def printHTMLstart( title ):
    print """
<html>
<head>
<title>%s</title>
<meta http-equiv="Content-type" content='text/html, charset="UTF-8"'>
</head>
<body onload="init()">
  <!--
  Troubleshooting:  if you are witnessing visible non-textual characters
  immediately after every forward slash "/" character, this indicates
  problems rendering the zero-width space in the Unicode character
  repertoire.  These characters often appear as small empty boxes.

  On Windows systems the zero-width space and other Unicode characters are
  added to the presentation repertoire by using the "Supplemental language
  support" checkboxes of the "Languages" tab of the "Regional and
  Language Options" selection of the Windows Control Panel application.

  Alternatively, you can remove all such references by changing the 
  definition of insChr below to the empty string as described below.

  To excise all scripting from this file, remove the onload= attribute from
  <body> and the <script> element below in its entirety.  This will remove
  security warning pop-ups in some browsers.
  -->
  <script type="text/javascript">

var zwsChr = String.fromCharCode(8203); // zero-width space (ZWS)
// var zwsChr = '';  // remove "//" from the start of this line to not use ZWS

function init() {
  // seed string with zero-width-spaces to promote good line breaking
  var xp = document.getElementsByTagName("samp");
  for (var p in xp) {
    if (xp[p].className == "xpath") {
      // insert zw spaces for nice line-breaks
      var steps = xp[p].firstChild.nodeValue.split("/");
      xp[p].firstChild.nodeValue = steps.join("/"+zwsChr);
    }
  }
}
</script>
<small>
""".encode( 'utf8' ) % title.encode( 'utf8' )

"""
the following clipboard stuff was excised on request

function i()
 {
   // alert(this.firstChild.nodeValue);
   // see http://www.krikkit.net/howto_javascript_copy_clipboard.html
   // in non-IE browsers, this functionality is disabled by default,
   // so we don't go to great efforts to try to make it work.
  if (window.clipboardData) {
   var steps = this.firstChild.nodeValue.split("/"+zwsChr)
   clipboardData.setData( 'Text',steps.join("/"));
   window.status= steps[ steps.length - 1 ] + " copied!";
   return true;
  }
 }
function h()
 {
  // show last during hover
  var steps = this.firstChild.nodeValue.split("/"+zwsChr)
  window.status= steps[ steps.length - 1 ];
  return true
 }
function o()
 {
  // clear hover text when leaving
  window.status='';
  return true
 }

      xp[p].onclick = i;
      xp[p].onmouseout = o;
      xp[p].onmouseover = h;
"""

def printHTMLentry( keyelem, keyattr, attrcard, indent, path, item ):
    key = "%d" % keyelem
    if keyattr > 0: key += ".%d" % keyattr
    print '<a name="key-%s"><samp>%s%s %s</samp> <samp' % \
          ( key, key, indent, attrcard ) + \
          ' class="xpath">%s</samp><br>' % ( path )


#=========================================================================
#
# Handlers processing the SAX stream of the input XPath file

# global storage
guri = {}

# simulate stacks
prefix = [ "" ]
uri = [ "" ]
element = [ "" ]
path = [ "" ]
text = [ false ]
outattrs = [ [] ]
ended = [ true ]
inMandatory = [ true ]

class myHandler( ContentHandler ):
    def startElementNS( this, ( euri, name ), qname, attrs ):
        if euri != xpathURI:
            # allow foreign elements without errors
            pass
        elif name == 'Element':
            # begin a new element, with a new key reference number
            global key
            global keyattr
            key += 1
            keyattr = 0
            thistext = false
            thisany = ""
            thistype = ""
            thisprefix = prefix[ -1 ]
            thisuri = uri[ -1 ]
            gotname = false
            gotloop = false
            min = ""
            max = ""
            gotreq = false
            gotopt = false
            for ( (ns, attr), value ) in attrs.items():
                # expected attributes
                if ns and ns != xpathURI:
                    #allow foreign attributes without errors
                    pass
                elif attr == 'name': thiselement = value; gotname = true
                elif attr == 'minOccurs': min = value
                elif attr == 'maxOccurs':
                    if value == 'unbounded': max = 'n'
                    else: max = value
                elif attr == 'required': gotreq = true
                elif attr == 'optional': gotopt = true
                # optional attributes
                elif attr == 'text': thistext = true
                elif attr == 'any': thisany = value
                elif attr == 'type': thistype = value
                elif attr == 'prefix': thisprefix = value
                elif attr == 'uri': thisuri = value
                elif attr == 'loop': gotloop = true
                elif attr == 'restricts': pass
                elif attr == 'extends': pass
                # unexpected attributes
                else:
                    sys.stderr.write( 'Unexpected attribute: %s="%s"\n(%s)\n' \
                                      % ( attr, value, path ) )

            if thisprefix != prefix[ -1 ]:
                # the running prefix has changed
                if thisuri == uri[ -1 ]:
                    # the running uri has not changed, so check for global uri
                    if guri.has_key( thisprefix ):
                        thisuri = guri[ thisprefix ]
                    else:
                        sys.stderr.write( 'Prefix without a local or global'\
                                   ' URI: %s\n' % ( thisprefix ) )

            if not( min!='' and max!='' and gotname ):
                sys.stderr.write( 'Incomplete element, missing attributes'\
                                  ': %s\n' % ( path ) )

            cardinality = "%s..%s" % ( min, max )
            path.append( path[ -1 ] + "/"+thisprefix+":"+thiselement )

            thisMandatory = inMandatory[ -1 ] and int(min) > 0
            suffix=''
            if not thistext: suffix = '/'
            if gotloop: suffix='//'
            if thisany == 'any': suffix='/*'
            if resulttext:
                if ( not minimal ) or thisMandatory:
                   print '%d   %s %s' % ( key, cardinality, path[ -1 ]+suffix )
            elif resulthtml: #html
                printHTMLentry( key, 0, cardinality, "&nbsp;&nbsp;&nbsp;",
                                    path[ -1 ]+suffix, thiselement )
            else: #xml
                if not ended[ -1 ]:
                    sys.stdout.write( ">" )
                    ended[ -1 ] = true
                print '\n%s<%s:%s' % ( "   " * ( len( element ) - 1 ),
                                     thisprefix, thiselement ),
                if prefix[ -1 ] == "":
                    # at the document element, so add all of the global URIs
                    gurikeys =  guri.keys()
                    gurikeys.sort()
                    for each in gurikeys:
                        sys.stdout.write( '\n  xmlns:%s="%s"' \
                                          % ( each, guri[ each ] ) )
                        
                if prefix[ -1 ] != thisprefix and \
                   not guri.has_key( thisprefix ):
                    sys.stdout.write( ' xmlns:%s="%s"' \
                                      % ( thisprefix, thisuri ) )

            inMandatory.append( thisMandatory )
            uri.append( thisuri )
            element.append( ( thiselement, key, cardinality ) )
            prefix.append( thisprefix )
            ended.append( false )
            outattrs.append( [] )
            text.append( thistext )

        elif name == 'Attribute':
            # begin an attribute for the current element
            keyattr += 1
            for ( (ns, attr), value ) in attrs.items():
                # expected attributes
                if ns and ns != xpathURI:
                    #allow foreign attributes without errors
                    pass
                elif attr == 'name': attrname = value
                elif attr == 'use': attruse = value
                elif attr == 'type': attrtype = value
                elif attr == 'restricts': pass
                elif attr == 'extends': pass
                # optional attributes
                elif 1 == 2: pass
                # unexpected attributes
                else:
                    sys.stderr.write( 'Unexpected attribute: %s="%s"\n(%s)\n' \
                                      % ( attr, value, path ) )
            if attruse == 'optional': attrcard = '0..1'
            else: attrcard = '1..1'
            outattrs[ -1 ].append( ( attrname, attrcard, keyattr ) )

            if resultxml:
                sys.stdout.write( ' %s="!%d.%d!"' \
                                 % ( attrname.encode( 'utf8' ), key, keyattr ))

        elif name == 'XPath':
            # beginning of the XPath document
            title = ''
            for ( (ns, attr), value ) in attrs.items():
                if ns and ns != xpathURI:
                    #allow foreign attributes without errors
                    pass
                elif attr == 'id': title = value + ' XPath information file'

            # titling of the result document
            if resulthtml:
                sys.stdout.write( '<!--%s-->' % title.encode( 'utf8' ) )
                if copyright:
                    sys.stdout.write( '<!--\n' + \
                                    string.join(copyright).encode( 'utf8' ) + \
                                      '\n-->' )
                printHTMLstart( title )
            elif resultxml:
                sys.stdout.write( '<?xml version="1.0" encoding="UTF-8"?>\n'+
                                  '<!--%s-->' % title.encode( 'utf8' ) )
                if copyright:
                    sys.stdout.write( '<!--\n' + \
                                    string.join(copyright).encode( 'utf8' ) + \
                                      '\n-->' )
            else: #text
                sys.stdout.write( '# %s\n' % title.encode( 'utf8' ) )
                if copyright:
                    sys.stdout.write( '# \n' )
                    for each in copyright:
                        sys.stdout.write( '# %s' % each.encode( 'utf8' ) )
                    sys.stdout.write( '# \n' )

        elif name == 'Namespace':
            # load up array of global namespaces
            thisprefix = ""
            thisuri = ""
            for ( (ns, attr), value ) in attrs.items():
                # expected attributes
                if attr == 'prefix': thisprefix = value
                elif attr == 'uri': thisuri = value
            guri[ thisprefix ] = thisuri
        
        else:
            # there are only three elements in the XPath vocabulary
            sys.stderr.write( 'Unexpected element: %s\n' % name )

        ContentHandler.startElementNS( this, ( euri, name ), qname, attrs )
        
    def endElementNS( this, ( euri, name ), qname ):
        if euri != xpathURI:
            # allow foreign elements without errors
            pass
        elif name == 'Element':
            ( thiselement, key, cardinality ) = element[ -1 ]
            if resulttext:
                if ( not minimal ) or inMandatory[ -1 ]:
                    for ( attrname, attrcard, keyattr ) in outattrs[ -1 ]:
                        if ( not minimal ) or attrcard == '1..1':
                            print '%d.%d %s %s/@%s'.encode( 'utf8' ) % \
                               ( key, keyattr, attrcard, path[ -1 ], attrname )
            elif resulthtml: #html
                for ( attrname, attrcard, keyattr ) in outattrs[ -1 ]:
                    printHTMLentry( key, keyattr, attrcard, "&nbsp;",
                                    path[ -1 ]+"/@"+attrname, "@"+attrname )
            else: #xml
                if not ended[ -1 ]:
                    sys.stdout.write( ">" )
                    ended[ -1 ] = true
                if text[ -1 ]:
                    sys.stdout.write( "!%d!" % key )
                else:
                    sys.stdout.write(  "\n%s" % \
                                       ( "   " * ( len( element ) - 2 ) ) )

                sys.stdout.write( "</%s:%s>" % \
                               ( prefix[ -1 ], thiselement.encode( 'utf8' ) ) )
            
            #pop items from stack
            inMandatory[ -1: ] = []
            prefix[ -1: ] = []
            uri[ -1: ] = []
            element[ -1: ] = []
            path[ -1: ] = []
            text[ -1: ] = []
            outattrs[ -1: ] = []

        ContentHandler.endElementNS( this, ( uri, name ), qname )

handler = myHandler()

#=============================================================================
#
# Main logic

parser = make_parser()
parser.setFeature( "http://xml.org/sax/features/namespaces", true)
parser.setContentHandler( handler )

try: # processing the input file using the defined SAX events
    parser.parse( sys.stdin )
except IOError, (errno, strerror):
    exit( "I/O error(%s): %s: %s" % (errno, strerror, "<stdin>" ) )
except SAXParseException:
    exit( "File does not parse as well-formed XML: %s" % "<stdin>" )

if resulthtml:
    print '</small></body></html>'

exit( )

# end of file
