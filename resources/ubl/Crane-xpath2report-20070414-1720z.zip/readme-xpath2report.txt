
readme-xpath2report.txt - An XPath reporting environment
========================================================

xpath2report.py is a Python application (tested under Python v2.3.3) that
reads an XPath file as iput and produces one of four kinds of output reports.

An XPath file is an innovation used in the development of two Universal
Business Language (UBL) 1.0 support packages:  the output specifications 
and the Small Business Subset specification.  The W3C XPath standard 
defines both a simple data model of the information found in any XML 
document and a syntax with which components of that data model can be 
addressed.  Unlike the W3C Document Object Model that specifies a data 
model of both the syntax and the information in an XML Document, the 
XPath data model does not preserve or express any aspects of the syntax 
used to mark up information found in an XML document, only the information
itself (that is, the elements, attributes, text and annotations).

An XML vocabulary is defined for XPath instances in order that the 
information expressed can be processed by XML-aware tools.  This vocabulary
of elements named <Element> and <Attribute>, and their attributes, is used 
to describe the complete catalogue of all elements and attributes in all 
possible contexts of instances of an XML document type.  Such a file can be
created in any fashion, for example, in UBL these files are created from an
analysis of the W3C Schema expressions.

The UBL 2.0 XPath file model is described by a normative ISO/IEC 19757-2
RELAX-NG schema and an approximate W3C Schema for validating the correct 
use of elements and attributes in an XPath instances.  These models can 
be found in the UBL HISC repository:

  http://www.oasis-open.org/committees/document.php?document_id=23525

Four reports can be generated from the normative XML instances, one HTML and
two text reports used for human consumption and one XML report used as a
diagnostic or reporting resource.  The HTML and full text reports catalogue
the complete absolute XPath address to every possible information item in 
every possible context, indicating any recursive references that would 
produce an infinite number of contexts.  A minimal text report catalogues 
only those XPath addresses of information items mandated by their 
cardinality (i.e. occurrence limitations) as being in the smallest possible
instance that validates with the UBL 2.0 schema for that document type.  The
XML instance report is a well-formed (but not valid) XML document with one
of every information item instantiated, using the reference number from the
full text report as the content of the item.

Invocation:

 Usage:  [-arg]*

 Standard input:  XPath file

 Standard output:  report file

 Mandatory argument (choose one of the following):

  -t{ype} xml  = xml instance report
  -t{ype} html = html report
  -t{ype} text = text report

 Optional arguments:

  -m{inimal}   = minimal text report
  -c{opyright} file = copyright file

========================================================
$Id: readme-xpath2report.txt,v 1.2 2007/04/14 17:12:53 G. Ken Holman Exp $
