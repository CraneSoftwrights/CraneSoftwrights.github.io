# Base logic to filter elements from an input stream based on parent/child
# relationships.
#
# This program is not run on its own; rather, another Python module imports
# this module while supplying the definition of namespace URI prefixes and
# allowed parent/child relationships.
#
# $Id: CraneUBLFilterBase.py,v 1.5 2008/10/24 01:44:23 gkholman Exp $

"""
Copyright (C) - Crane Softwrights Ltd. - http://www.CraneSoftwrights.com/

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice, 
  this list of conditions and the following disclaimer. 
- Redistributions in binary form must reproduce the above copyright notice, 
  this list of conditions and the following disclaimer in the documentation 
  and/or other materials provided with the distribution. 
- The name of the author may not be used to endorse or promote products 
  derived from this software without specific prior written permission. 

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN 
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2002-12-16 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5
"""

usage = """
Usage:  [-?]  <unfiltered-standard-input >filtered-standard-output

 -?       = display usage
"""

import sys,string
from xml.sax import make_parser, SAXParseException
from xml.sax.handler import ContentHandler
from xml.sax.saxutils import XMLGenerator

false = 0
true = not( false )

echo = false

def errorExit( str ):
    sys.stderr.write( str )
    sys.exit( 1 )

#=========================================================================
#
# Argument processing

badopt = false
while len( sys.argv ) > 1 and \
      ( sys.argv[1][0] == '/' or sys.argv[1][0] == '-' ):
    opt = sys.argv[1][1:]
    if opt == '?' or opt == '-help':
        sys.stderr.write( usage )
        sys.exit( 0 )
    sys.argv[ 1:2 ] = [] # remove argument

if len( sys.argv ) != 1 or badopt: # cannot proceed as requested by user
    errorExit( usage )

if __name__ == '__main__':
    errorExit( """
The code in filterUBL.py is not designed for standalone use.  Please
invoke a Python program that imports this file, supplying the necessary
filter information.
""" )

#=========================================================================
# Library has to be at a certain level

def atLeastPythonVersion( atLeastMajor, atLeastMinor, atLeastRevision ):
    ( major, minor, revision ) = map( int,
                              string.split( string.split(sys.version)[0],'.') )

    if major < atLeastMajor:
        return false
    if minor < atLeastMinor:
        return false
    if revision < atLeastRevision:
        return false
    return true

if not atLeastPythonVersion( 2, 5, 1 ):
    errorExit( """

The running version of Python (%s) does not have an up-to-date
library for the required XML processing.  Please use Python 2.5.1 or
later.  If you are using an appropriate version and you have obvious
problems, please report this to info@CraneSoftwrights.com
""" % string.split(sys.version)[0] )

#=========================================================================
# Handle an event and pass on for further events

parentChild = {}
prefixes = {}
description = ""

inOutStack = [ true ] # top of stack true indicates current element acceptable
parentStack = [] # each value = ( prefixed name, allowed kids, kids so far )
inExtStack = [ false ] # top of stack indicates within a UBL extension
documentElementChecked = false

class myHandler( XMLGenerator ):
    def startElementNS( this, ( uri, name ), qname, attrs):
        global documentElementChecked
        # what's going on so far?
        inOut = inOutStack[-1]
        inExt = inExtStack[-1]

        # for brevity (and hopefully speed), use the prefix instead of the URI
        if prefixes.has_key( uri ):
            prefixedName = prefixes[ uri ] + ":" + name
        else:
            prefixedName = None

        if inOut:
            # not current being skipped
            if not documentElementChecked:
                # check that the document element is expected
                documentElementChecked = true
                if not parentChild.has_key( prefixedName ):
                    errorExit( "Unexpected document element: {%s}%s" %
                               ( uri, name ) )
            elif inExt:
                # in an extension so preserve all in the extension
                inOut = true
            elif prefixedName == 'ext:ExtensionContent':
                # starting an extension so preserve all in the extension
                inExt = true
                inOut = true
            else:
                # determine the properties of the parent
                parent = parentStack[ -1 ]
                allowed = parent[ 1 ]
                # check this is allowed by the parent
                if not allowed.has_key( prefixedName ):
                    inOut = false
                # allowed by name, but what about by cardinality?
                else:
                    cardinality = allowed[ prefixedName ]
                    if cardinality == 0:
                        pass # all quantities of children allowed
                    elif cardinality == 1:
                        # special case a maximum of one
                        if prefixedName in parent[2]:
                            # already have one of these, max is one
                            inOut = false
                    elif parent[2].count( prefixedName ) >= cardinality:
                        # use the slower count() function for more than one
                        inOut = false
                # count this element as a child of the parent
                parent[2].append( prefixedName )
                
        # prepare and remember the new status of processing for children
        children = {}
        if parentChild.has_key(prefixedName):
            children = parentChild[prefixedName]
        inOutStack.append( inOut )
        inExtStack.append( inExt )
        parentStack.append( ( prefixedName, children ,[()] ) )
        if inOut:
            XMLGenerator.startElementNS( this, ( uri, name), qname, attrs )

    def characters( this, content ):
        if inOutStack[-1]:
            # only put out text if the parent is in allowed set
            XMLGenerator.characters( this, content )

    def endElementNS( this, ( uri, name ), qname ):
        # restore status of processing for siblings
        parentStack.pop()
        inExtStack.pop()
        if inOutStack.pop():
            XMLGenerator.endElementNS( this, ( uri, name), qname )

# use UTF-8 per the UBL guidelines
handler = myHandler( None, "UTF-8" )

#=============================================================================
#
# Main logic

def FilterUBL( parentChildDict, prefixesDict ):
    global parentChild,prefixes

    # stablish global from calling module
    parentChild = parentChildDict
    prefixes = prefixesDict

    # set up XML processing
    parser = make_parser()
    parser.setFeature( "http://xml.org/sax/features/namespaces", true)
    parser.setContentHandler( handler )

    try: # processing the input file using the defined SAX events
        parser.parse( sys.stdin )
    except IOError, (errno, strerror):
        if errno == 12:
            # empirically, this is what one gets when no file on stdin
            errorExit( usage )
        else:
            # something else is wrong
            errorExit( "I/O error(%s): %s: %s" % (errno, strerror, file) )
    except SAXParseException:
        # there was an XML processing error
        errorExit( "File does not parse as well-formed XML: %s" % file )

# end of file
