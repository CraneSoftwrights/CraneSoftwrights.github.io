Crane-gc2summary-obfuscated.xsl

This is a stylesheet to generate the summary HTML reports of CCTS models.

Copyright (C) - Crane Softwrights Ltd. 
              - http://www.CraneSoftwrights.com/links/res-dev.htm

Portions copyright (C) - OASIS Open 2015. All Rights Reserved.
                       - http://www.oasis-open.org/who/intellectualproperty.php

Typical invocation:

  java -jar saxon9he.jar {arguments}

Mandatory invocation arguments (URIs are relative to input genericode file):

 - stylesheet file:                        -xsl:Crane-gc2summary-obfuscated.xsl
 - input genericode file                   -s:{filename}
 - placebo output in target directory      -o:{dir}/junk.out
 - title prefix for the head of the report title-prefix={string}

Optional invocation arguments:

 - time stamp for the package             date-time={string}
 - which models to report on              model-regex={string}
 - which profile to report on             subset-column-name={string}
 - reveal the pruned BIEs                 reveal-non-subset=yes/no (default no)
 
Necessary invocation argument when the common library has exactly one ABIE:

 - specify the model name          common-library-singleton-model-name={string}

THE AUTHOR MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS CODE FOR ANY
PURPOSE. THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN 
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

IMPLEMENTATION NOTE:

This stylesheet logic does not accommodate qualified object classes.

TECHNICAL NOTE:

This stylesheet has been purposely obfuscated and all comments have been
removed.  Please respect our copyright and do not attempt to reverse 
engineer the techniques involved.
