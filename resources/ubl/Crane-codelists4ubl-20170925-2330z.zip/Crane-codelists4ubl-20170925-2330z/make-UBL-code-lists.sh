# Dependencies
#
ant=/Users/admin/p/apache/ant
saxon=/Users/admin/p/xml/xslt/saxon9he/saxon9he.jar
xjparse=/Users/admin/p/xml/xml/xjparse/xjparse.jar

if [ "$3" == "" ]
then 
echo Missing stage, dateZ and date arguments
exit
fi

if [ ! -e "master-code-list-UBL-2.2-$1.xml" ]
then
echo Missing input file: master-code-list-UBL-2.2-$1.xml
exit
fi

java -jar $saxon -xsl:Crane-list2ant.xsl -s:master-code-list-UBL-2.2-$1.xml -o:make-code-list.ant.xml "raw-uri-prefix=raw/" "intermediate-uri-prefix=work/" "output-uri-prefix=$1/"

if [ "$?" != "0" ]; then exit ; fi

echo Building packager...
java -Dant.home=$ant -classpath $xjparse:$ant/lib/ant-launcher.jar:$saxon:. org.apache.tools.ant.launch.Launcher -buildfile make-code-list.ant.xml

if [ "$?" != "0" ]; then exit ; fi

echo Packaging package...
java -Dant.home=$ant -classpath $ant/lib/ant-launcher.jar:$saxon:. org.apache.tools.ant.launch.Launcher -buildfile package-UBL-distribution.xml -Ddir=package/ -Dstage=$1 -Dversion=$2 -Ddatetimelocal=$3 -DUBL=2.2

b
b
