Crane-checkgc4ublndr-obfuscated.xsl

This is a stylesheet to analyze the genericode representation of a UBL NDR 3.0
CCTS model, reporting on inconsistencies or invalidly-expressed values. The
version of NDR implemented by these stylesheets is found at:

  http://docs.oasis-open.org/ubl/UBL-NDR/v3.0/UBL-NDR-v3.0.html
  
Note that only the COMxx and MODxx rules that are programmatically tested are
tested by this stylesheet, as those rules are for the CCTS model.  This
stylesheet does not test any generated schemas for conformance to the NDR,
a genericode-expressed CCTS model.

When two models are supplied as arguments the stylesheet creates reports of
the differences between the two, including an analysis of non-backward-
compatible changes.  The difference reports can be exported as DocBook tables.

Please see "CreatingExtensionsWithUBLNDR.html" for an illustration of using
these stylesheets

Copyright (C) - Crane Softwrights Ltd. 
              - http://www.CraneSoftwrights.com/links/training-gctk.htm

Portions copyright (C) - OASIS Open 2015. All Rights Reserved.
                       - http://www.oasis-open.org/who/intellectualproperty.php

This documentation and the URI resolution of the XSLT processor both presume
the use of the free Saxon9HE XSLT processor from http://saxon.sf.net ... if
that XSLT 2.0 processor is not being used, then the results may not be as
expected.

Typical invocation (HTML output to standard output):

  java -jar saxon9he.jar {arguments}

Mandatory Invocation arguments (URI's are relative to the input):

 - stylesheet file:            -xsl:Crane-checkgc4ublndr-obfuscated.xsl
 - input new genericode file   -s:{filename}
 - output HTML file            -o:filename
 - document title suffix       "title-suffix={string}"
 - change column title suffix  "change-suffix={string}"
 - configuration details*      +config={filename} or config-uri={filename}

Optional invocation arguments (URI's are relative to the input):

 - old genericode file         +old={filename} or old-uri={filename}
   (to specify an older version of the model to analyze a comparison)
 - base genericode file        +base={filename} or base-uri={filename}
   (to specify a base library for use by extension components)

Optional invocation arguments (URI's are relative to the output):

 - output DocBook file URI common    docbook-common-uri=file://{filename}
 - output DocBook file URI maindoc   docbook-maindoc-uri=file://{filename}

Necessary invocation argument when the common library has exactly one ABIE:

 - specify the model name      common-library-singleton-model-name={string}

THE AUTHOR MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS CODE FOR ANY
PURPOSE. THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR 
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN 
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED 
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

TECHNICAL NOTE:

This stylesheet has been purposely obfuscated and all comments have been
removed.  Please respect our copyright and do not attempt to reverse 
engineer the techniques involved.

* Input file description

Configuration details file:

 - this is the same configuration file that is input to the Crane-gc2ublndr
   stylesheet that creates the schemas from the CCTS model

(For those readers who are curious, the latest NDR document is dated after the
UBL 2.1 schemas were published and so there are a number of errors reported for
UBL 2.1 that will be repaired in future versions)