if [ "$3" == "" ]
then 
echo Missing stage, dateZ and date arguments
exit
fi

if [ ! -e "master-code-list-UBL-2.2-$1.xml" ]
then
echo Missing input file: master-code-list-UBL-2.2-$1.xml
exit
fi

java -jar /Users/admin/p/xml/xslt/saxon9he/saxon9he.jar -xsl:Crane-list2ant.xsl -s:master-code-list-UBL-2.2-$1.xml -o:make-code-list.ant.xml "raw-uri-prefix=raw/" "intermediate-uri-prefix=work/" "output-uri-prefix=$1/"

if [ "$?" != "0" ]; then exit ; fi

echo Building package...
java -Dant.home=/Users/admin/p/apache/ant -classpath /Users/admin/p/xml/xslt/saxon/saxon.jar:/Users/admin/p/apache/ant/lib/ant-launcher.jar:/Users/admin/p/xml/xslt/saxon9he/saxon9he.jar:. org.apache.tools.ant.launch.Launcher -buildfile make-code-list.ant.xml

if [ "$?" != "0" ]; then exit ; fi

echo Packaging package...
java -Dant.home=/Users/admin/p/apache/ant -classpath /Users/admin/p/xml/xslt/saxon/saxon.jar:/Users/admin/p/apache/ant/lib/ant-launcher.jar:/Users/admin/p/xml/xslt/saxon9he/saxon9he.jar:. org.apache.tools.ant.launch.Launcher -buildfile package-UBL-2.2.xml -Ddir=package/ -Dstage=$1 -Dversion=$2 -Ddatetimelocal=$3

b
b
