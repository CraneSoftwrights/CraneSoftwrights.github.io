# Illustration of the use of the Python API:
#
#     Download and save all documents for the account associated with
#     the access credentials found in the file named by the first
#     command-line argument.
#
# $Revision: 1.10 $$Date: 2013/04/13 19:30:15 $

import CraneTradeshiftAPI
import sys

def retString( ret, response ):
    return 'Problem "%s" accessing API\n%s' % ( ret, response.__str__() )

# ensure the command line argument is available
if len(sys.argv) != 2:
    print >>sys.stderr,"Exactly one argument needed: "+\
                       "the access credentials filename"
    sys.exit(1)

# create an instance of the API to use
t = CraneTradeshiftAPI.API.CreateFromXMLFile( sys.argv[1] )

# walk through the pages of documents available:

page = 0 # pages counted from zero
while True:
    # get the next page of documents (not all arrive in a single call) 
    ( response, docList ) = t.raw( "get", 
                                   "external/documents?page=%d" % page )
    ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
    if ret != "200": raise Exception,retString(ret,response)
    
    # these values will be the same for every loop
    count = docList['itemCount']
    itemsPerPage = docList['itemsPerPage']
    numPages = docList['numPages']
    if count == 0: 
        print "No documents." 
        break
    
    print "Page number %d for %d documents, %d per page for %d pages:" % \
          ( page, count, itemsPerPage, numPages )
        
    # walk through this page of documents
    pageDocs = docList['Document']
    for each in pageDocs:
        # determine the identifier of the next document in the list
        id = each['DocumentId']
    
        # display status
        print "Getting document %s (%s) ..." % \
              ( id, each['DocumentType']['type'] )
    
        # get that document's metadata as XML
        ( response, xml ) = t.raw( "get", 
                                   "external/documents/%s/metadata" % id,
                                   dataType = "text/xml")
        ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
        if ret != "200": raise Exception,retString(ret,response)
        # write the metadata out
        meta = open( "%s.meta.xml"%id, "w" )
        meta.write( xml )
        meta.close()
    
        # download the document as XML
        ( response, xml ) = t.raw( "get", "external/documents/%s" % id,
                                   dataType="text/xml" )
        ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
        if ret != "200": raise Exception,retString(ret,response)
        # write the document out
        out = open( "%s.xml"%id, "w" )
        out.write( xml )
        out.close()

    # go to the next page
    page += 1
    if page == numPages: break # but not if there isn't a next page
    
# end of file
