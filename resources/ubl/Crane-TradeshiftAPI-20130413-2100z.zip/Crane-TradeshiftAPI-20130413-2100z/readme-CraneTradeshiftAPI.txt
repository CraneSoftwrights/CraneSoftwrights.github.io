
CraneTradeshiftAPI.py $Revision: 1.60 $ $Date: 2013/04/13 21:00:21 $

A Python language interface to http://Tradeshift.com's 2-legged-OAuth-based 
API to http://go.Tradeshift.com following the API documentation 2013-03-31 at:

  http://developer.tradeshift.com/rest-api/
  http://api.tradeshift.com/tradeshift/rest/external/doc
  
Dependencies: httplib:   http://docs.python.org/library/httplib.html
                         "socket" module compiled with SSL support
                         (error: AttributeError: 'module' object has no 
                                                 attribute 'HTTPSConnection')
              oauth2:    http://github.com/dgouldin/python-oauth2
              httplib2:  http://code.google.com/p/httplib2/
              Python 2.6 (may work in Python 2.5 but not tested)

The only required module from the distribution is CraneTradeshiftAPI.py - all
other files are documentation and examples.

Used as an importable library:   import CraneTradeshiftAPI

    A Python-based abstraction to the http://www.Tradeshift.com application
    programmer's interface, plus a raw access function call on which to build.

    Please see the API class documentation below for usage details or print
    from interactive Python:
          python
          >>> import CraneTradeshiftAPI
          >>> print CraneTradeshiftAPI.API.__doc__
          >>> quit()

    Sample programs using the importable library: 
      downloadAllDocumentsSample.py
               - a sample application to download and store all documents and
                 their associated metadata
               - illustrates the use of "GET" in the API
      deleteNewestDraftSample.py
               - a sample application to delete the newest draft document    
               - illustrates the use of "DELETE" in the API
      draftNewInvoiceFromNewestSample.py
               - a sample application to create a new document that is a
                 duplicate of the newest invoice document
               - illustrates the use of "PUT" of XML in the API
      diagnoseDocumentSample.py
               - a sample application to diagnose the validity of a putative
                 new document
               - illustrates the use of "POST" of XML in the API
      dispatchNewestDraftSample.py
               - a sample application to dispatch the newest draft document
               - illustrates a "PUT" of Python in the API
      displayNewestDraftSample.py
               - a sample application to display relevant information
                 regarding the newest draft document
               - illustrates the use of XPath

    Sample program dependencies (indirectly through CraneUBLAPI):
      xpath: http://code.google.com/p/py-dom-xpath/ 

Used as a command-line main module: 

    python CraneTradeshiftAPI.py {flags} {args}

    A command-line interface to the raw Tradeshift API.  Use this to interact
    with the API without any programming by using only command-line 
    invocations and file system files for input and output.

    Please see the __main__ documentation below for usage details or print
    from interactive Python:
          python
          >>> import CraneTradeshiftAPI
          >>> print CraneTradeshiftAPI.Main.__doc__
          >>> quit()

    Input: sampleAccess.xml - a sample XML-based expression of access
                              credentials for the Tradeshift API combining the
                              site, the tenant, the access key and the password
                            - please note that the password is in clear text
                              and thus is not protected in any way

Copyright (C) - Crane Softwrights Ltd.
              - http://www.CraneSoftwrights.com/links/res-ts.htm

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
- The name of the author may not be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2003-07-26 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

THE AUTHOR MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS CODE FOR ANY
PURPOSE.

Revision history (major features only post 1.57; minor issues not recorded):

Release: 1.60 - 20130413-2100z - rewrite with 2-legged OAuth


