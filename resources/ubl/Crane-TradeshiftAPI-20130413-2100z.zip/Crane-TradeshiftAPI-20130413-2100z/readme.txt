CraneTradeshiftAPI package:  an interface to the 2-legged OAuth Tradeshift API

The only file from this package that needs to be copied to your
programming environment is:

   CraneTradeshiftAPI.py

The other files are documentation and examples.  For a list of dependencies
and usage information please read this for details:

   readme-CraneTradeshiftAPI.txt

A useful module for access to UBL constructs is:

   CraneUBLAPI.py
   
The documentation for this module is in: 

   readme-CraneUBLAPI.txt

=================================
$Date: 2013/04/13 21:00:22 $
