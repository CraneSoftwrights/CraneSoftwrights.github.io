
CraneUBLAPI.py $Revision: 1.8 $ $Date: 2013/04/13 21:00:20 $

A Python language library of constants and classes related to the
OASIS Universal Business Language (UBL).

Dependencies: xpath   # from http://code.google.com/p/py-dom-xpath/

Note: while this library is distributed as part of Crane's API interface to 
      Tradeshift, facilities found herein are in no way tied to that interface.
      The dispatchNewestInvoiceSample.py application briefly illustrates the
      use of this library.

Contents: 

(1) Some useful constants when working with UBL documents:

    CAC # the namespace for all Common Aggregate Components
    CBC # the namespace for all Common Basic Components
    EXT # the namespace for all Common Extension Components
    SIG # the namespace for apex Signature Extension element
    SAC # the namespace for all Signature Extension Aggregate Components
    SBC # the namespace for all Signature Extension Basic Components
        # e.g.  from CraneUBLAPI import *
        # e.g.  (when using xml.dom.minidom)
        #       paymentMeans = x.getElementsByTagNameNS(CAC,"PaymentMeans")

    # get the version of this API implementation
    print CraneUBLAPI.VERSION

(2) UBLXPathContext class:

    An extension of the py-dom-xpath class XPathContext pre-loaded with
    UBL namespace prefix bindings.

    Please see the API class documentation below for usage details or print
    from interactive Python:
    
          python
          >>> import CraneUBLAPI
          >>> print CraneUBLAPI.UBLXPathContext.__doc__
          >>> quit()

Future work:
 - create a UBL document from a Python structure of invoice information

Copyright (C) - Crane Softwrights Ltd.
              - http://www.CraneSoftwrights.com/links/res-ts.htm

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
- The name of the author may not be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2003-07-26 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

THE AUTHOR MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS CODE FOR ANY
PURPOSE.

Revision history (major features only; minor issues not recorded):

Release: 1.8 - 20130413-2100z - Arg check; document exposition
Release: 1.6 - 20110606-0150z - Optional args; add fullpath
Release: 1.4 - 20110528-1810z - Fix version number; document example
Release: 1.2 - 20110528-1640z - Add XPathContext support
Release: 1.1 - 20101030-1920z - Initial version

