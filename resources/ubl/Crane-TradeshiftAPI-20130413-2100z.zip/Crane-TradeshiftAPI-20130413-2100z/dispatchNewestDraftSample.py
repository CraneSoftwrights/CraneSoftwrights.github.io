#. Illustration of the use of the Python API:
#
#     dispatch the newest invoice document in storage
#
# $Revision: 1.11 $$Date: 2013/04/13 19:30:14 $

import CraneTradeshiftAPI   # Crane's implementation of the Tradeshift API
import CraneUBLAPI          # Crane's implementation of a UBL API
import uuid                 # UUID objects according to RFC 4122
import re                   # Regular expression operations
import sys                  # System-specific parameters and functions
import time                 # Time access and conversions

def retString( ret, response ):
    return 'Problem "%s" accessing API\n%s' % ( ret, response.__str__() )

# ensure the command line argument is available
if len(sys.argv) != 2:
    print >>sys.stderr,"Exactly one argument needed: "+\
                       "the access credentials filename"
    sys.exit(1)

# create an instance of the API to use
t = CraneTradeshiftAPI.API.CreateFromXMLFile( sys.argv[1] )

# get the newest invoice details from the document list
( response, docList ) = t.raw( "get", 
                         "external/documents?type=invoice&limit=1&stag=draft" )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "200": raise Exception,retString(ret,response)

# these values will be the same for every loop
count = docList['itemCount']
if count == 0:
    print "No invoice found to duplicate."
    sys.exit(0)

# only need first document; default is descending edited date order
newest = docList['Document'][0]
id = newest['DocumentId']
profile = newest['DocumentType']['documentProfileId']
try:
    # first try assuming that the document has already been dispatched
    connectionID = newest['LatestDispatch']['ReceiverConnectionId']
except:
    # there is no latest dispatch if it is a new document never dispatched
    print "No connection ID found; determine from party identifier"
    ( response, doc ) = t.rawDOM( "get", 
                                  "external/documents/%s" % id )
    ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
    if ret != "200": raise Exception,retString(ret,response)
    ubl = CraneUBLAPI.UBLXPathContext( doc )
    customer = ubl.findnode( "/*/cac:AccountingCustomerParty/cac:Party" )
    partyID = ubl.findvalue( "cac:PartyIdentification/"+\
                             "cbc:ID[@schemeID='TS:ID']", customer )
    email = None
    if partyID:
        print "Looking for party ID:", partyID
    else:
        print "No party identifier found; determine from invoice target email"
        email = ubl.findvalue( "cac:Contact/cbc:ElectronicMail", customer )
        if not email:
            print "No email address found; giving up"
            sys.exit(1)
        print "Looking for email:",email
        
    # walk through all connections until email address is found
    page = 0 # pages counted from zero
    connectionID = None
    while True:
        # get the next page of connections (not all arrive in a single call) 
        ( response, cnctList ) = t.raw( "get", 
                                "external/network/connections?page=%d" % page )
        ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
        if ret != "200": raise Exception,retString(ret,response)
        numPages = cnctList['numPages']
        # walk through all connections on this page
        for each in cnctList[ "Connection" ]:
            # check if the party has been found
            if partyID and each.has_key("CompanyAccountId"):
                if each[ "CompanyAccountId" ] == partyID:
                    connectionID = each[ "ConnectionId" ]
                    break
            # check if the email has been found
            if email and each.has_key("Email"):
                if each[ "Email" ] == email:
                    connectionID = each[ "ConnectionId" ]
                    break
        if connectionID: break
        page += 1
        if page == numPages: break

    if not connectionID:
        print "No connection ID found; giving up"
        sys.exit(1)

# create a dispatch identifier
dispatchID = uuid.uuid4().__str__()
# create a dispatch request
print "Dispatching %s" % id
print "         to %s" % connectionID
print "      using %s ..." % dispatchID
(response, dispatch) = t.raw( "put", 
                              "external/documents/%s/dispatches/%s" % \
                                                     ( id, dispatchID ),
                              { "ConnectionId":connectionID } )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "201": raise Exception,retString( ret, response )

print "Getting the dispatch status of the document...",
while True:
    (response,status) = t.raw( "get",
                           "external/documents/%s/dispatches/latest" % ( id ) )
    ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
    if ret != "200": raise Exception,retString( ret, response )
    if "ReceiverConnectionId" in status: break
    if status["DispatchState"] != 'ACCEPTED': break
    print ".",
    time.sleep(1)
print

for each in status:
  print "%s: %s" % ( each, status[each] ) 

# end of file
