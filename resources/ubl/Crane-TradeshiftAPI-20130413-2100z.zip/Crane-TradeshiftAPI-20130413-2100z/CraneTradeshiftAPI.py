"""
CraneTradeshiftAPI.py $Revision: 1.60 $ $Date: 2013/04/13 21:00:21 $

A Python language interface to http://Tradeshift.com's 2-legged-OAuth-based 
API to http://go.Tradeshift.com following the API documentation 2013-03-31 at:

  http://developer.tradeshift.com/rest-api/
  http://api.tradeshift.com/tradeshift/rest/external/doc
  
Dependencies: httplib:   http://docs.python.org/library/httplib.html
                         "socket" module compiled with SSL support
                         (error: AttributeError: 'module' object has no 
                                                 attribute 'HTTPSConnection')
              oauth2:    http://github.com/dgouldin/python-oauth2
              httplib2:  http://code.google.com/p/httplib2/
              Python 2.6 (may work in Python 2.5 but not tested)

The only required module from the distribution is CraneTradeshiftAPI.py - all
other files are documentation and examples.

Used as an importable library:   import CraneTradeshiftAPI

    A Python-based abstraction to the http://www.Tradeshift.com application
    programmer's interface, plus a raw access function call on which to build.

    Please see the API class documentation below for usage details or print
    from interactive Python:
          python
          >>> import CraneTradeshiftAPI
          >>> print CraneTradeshiftAPI.API.__doc__
          >>> quit()

    Sample programs using the importable library: 
      downloadAllDocumentsSample.py
               - a sample application to download and store all documents and
                 their associated metadata
               - illustrates the use of "GET" in the API
      deleteNewestDraftSample.py
               - a sample application to delete the newest draft document    
               - illustrates the use of "DELETE" in the API
      draftNewInvoiceFromNewestSample.py
               - a sample application to create a new document that is a
                 duplicate of the newest invoice document
               - illustrates the use of "PUT" of XML in the API
      diagnoseDocumentSample.py
               - a sample application to diagnose the validity of a putative
                 new document
               - illustrates the use of "POST" of XML in the API
      dispatchNewestDraftSample.py
               - a sample application to dispatch the newest draft document
               - illustrates a "PUT" of Python in the API
      displayNewestDraftSample.py
               - a sample application to display relevant information
                 regarding the newest draft document
               - illustrates the use of XPath

    Sample program dependencies (indirectly through CraneUBLAPI):
      xpath: http://code.google.com/p/py-dom-xpath/ 

Used as a command-line main module: 

    python CraneTradeshiftAPI.py {flags} {args}

    A command-line interface to the raw Tradeshift API.  Use this to interact
    with the API without any programming by using only command-line 
    invocations and file system files for input and output.

    Please see the __main__ documentation below for usage details or print
    from interactive Python:
          python
          >>> import CraneTradeshiftAPI
          >>> print CraneTradeshiftAPI.Main.__doc__
          >>> quit()

    Input: sampleAccess.xml - a sample XML-based expression of access
                              credentials for the Tradeshift API combining the
                              site, the tenant, the access key and the password
                            - please note that the password is in clear text
                              and thus is not protected in any way

Copyright (C) - Crane Softwrights Ltd.
              - http://www.CraneSoftwrights.com/links/res-ts.htm

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
- The name of the author may not be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2003-07-26 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

THE AUTHOR MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS CODE FOR ANY
PURPOSE.

Revision history (major features only post 1.57; minor issues not recorded):

Release: 1.60 - 20130413-2100z - rewrite with 2-legged OAuth

"""

from __future__ import with_statement # needed when using Python 2.5
# standard libraries
import sys             # System-specific parameters and functions
import httplib         # HTTP protocol client
import xml.sax         # Support for SAX2 parsers
import xml.sax.handler # Base classes for SAX handlers
import threading       # Higher-level threading interface
import re              # Regular expression operations
import json            # JSON encoder and decoder
import xml.dom.minidom # Lightweight DOM implementation
import cStringIO       # Read and write strings as files

# other libraries imported here to ensure their presence later
import httplib2      # from http://code.google.com/p/httplib2/ (used by oauth2)
import oauth2        # from http://github.com/dgouldin/python-oauth2

# what is exposed in this API?  Only the API and the command-line application

__all__ = [ "API", "Main" ]

VERSION = "$Revision: 1.60 $"[11:-2]

###############################################################################
#
# API implementation
#

class API( object ):
    """
CraneTradeshiftAPI.py $Revision: 1.60 $ $Date: 2013/04/13 21:00:21 $

# A Python abstraction to the 2-legged OAuth API of http://www.Tradeshift.com

import CraneTradeshiftAPI

# Use one of the following two schemes to create an instance of the API class
# (for example, named "t") with these four initializing values:
#
# baseURI  = the base URI of the Tradeshift host and API interface (including
#            the web site and everything needed up to and including "rest")
#            e.g.: "api.Tradeshift.com/tradeshift/rest"
#            Note the domain name is not case sensitive, but the rest of the
#            string is case sensitive; a trailing "/" is added if not provided
# tenantId = the tenant's unique identifier on the given Tradeshift service
#            (note this is not the Tradeshift user identifer, but the tenant's)
# key      = the consumer key with permission to access the tenant's API
# secret   = the secret password associated with the consumer key
# agent    = (optional) replacement for this library's built-in agent string
#
t=CraneTradeshiftAPI.API.CreateFromStrings("baseURI","tenantId","key","secret",
                                           "optional-agent")
t=CraneTradeshiftAPI.API.CreateFromXMLFile("filename", "optional-agent")
    where the file at the filename reads as either a single XML element, e.g.:
        <CraneTradeshiftAPIAccess
          baseURI     = "api.Tradeshift.com/tradeshift/rest"
          tenantId    = "12345678-1234-1234-1234-123456789ABC"
          key         = '123456789ABCDEFGHIJK'
          keySecret   = '123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-1234'
          token       = '987654321ZYXWVUTSRQP'
          tokenSecret = '987654321ZYXWVUTSRQPONMLKJIHGFEDCBA-9876'
        />
    or as a wrapper element with children, e.g.:
        <CraneTradeshiftAPIAccess>
          <baseURI>https://api-sandbox.Tradeshift.com/tradeshift/rest</baseURI>
          <tenantId>99aaa165-597a-4db5-b2ec-8e6ef96a079d</tenantID>
          <key secret='3EeCVbnzs2jyrvMm8gooGnW95eqReljkFom4eNDL'
                                      >CraneSoftwrightsLtdAPIT1xv9putLpVl</key>
          <token secret='j@MS3q6y@C8feHUnFZx733rcPDNx+VVeMTF8cKNe'
                                      >8S7@BweVGPq-qhB7WzDgh2phFbEb9a</token>
        </CraneTradeshiftAPIAccess>

# get the version of this API implementation
print CraneTradeshiftAPI.VERSION

# a raw method for the API without any semantic abstraction of the information
# (use the call appropriate to the data type of the returned data) 

( response, data ) = t.raw( action, resource, content, 
                            contentType, responseType, dataType )

( response, xmlMiniDOMDocument ) = t.rawDOM( action, resource, content, 
                                             contentType, responseType )

  # response = summary of request and response information
  # data = data returned from the API according to the passed data type
  # xmlMiniDOMDocument = data returned from the API as a DOM object
  #
  # action = "GET"|"PUT"|"DELETE"|"POST" - no default; not case sensitive
  # resource = no default; no lead "/"; added to baseURI; case-sensitive value
  #     e.g. "external/documents?page=2"
  #     e.g. "external/info/countryprofiles/CA
  # content = optional supplied content for a "PUT"/"POST" action
  # contentType = indicated type for the supplied content
  #             = "text/xml" for an XML string, 
  #               "application/json" for a JSON string,
  #               "text/plain" for a simple string,
  #            or "" (default) for a Python xml.dom.minidom.Document instance
  #                  of an XML structure or a Python list/directory structure 
  #                  for other documents
  # responseType = requested type for the returned request/response information
  #              = "text/xml" for an XML string, 
  #                "application/json" for a JSON string,
  #                dict (default) for a Python list/directory structure,
  #             or xml.dom.minidom.Dictionary for a MiniDOM instance
  #             (Note these last two values are not strings, rather, they
  #              are a Python type and a Python class)
  # dataType = requested type for returned data information
  #            = "text/xml" for an XML string, 
  #              "application/json" for a JSON string (not for documents), 
  #              "text/plain" for a simple string,
  #              "text/html" for an HTML string,
  #              dict (default) for a Python list/directory structure,
  #           or xml.dom.minidom.Document for a MiniDOM XML document instance
  #           (Note these last two values are not strings, rather, they
  #            are, respectively, a Python type and a Python class)
  #
  # Note that this API will translate a text/plain response into a text/xml
  # response when dataType is text/xml, using an instance with a single
  # element {http://www.CraneSoftwrights.com/ns/TS-api}CraneTradeshiftAPIText

# a convenience function to determine the status string from the REST response
status = CraneTradeshiftAPI.API.StatusFromResponse( response )
 
  # response = return value from a call to t.raw()
    
# semantic abstractions in the API are not yet implemented
"""

#============
#
# Class instance initialization

    # The class instance configuration information is supplied in strings
    @staticmethod  # called without first-argument class
    def CreateFromStrings( baseURI, tenantId, key, keySecret, 
                           token, tokenSecret, agentString="" ):
        global __mysteryString
        #the following cannot be distilled into a common call because one
        #needs to make the instance of the class before calling a method
        with threading.Lock(): # make access to changing global thread-safe
            __mysteryString = "CraneTradeshiftAPIMysteryString"
            api = API( )
            __mysteryString = ""
        return api.__RawCreateFromStrings( baseURI, tenantId, key, keySecret,
                                           token, tokenSecret, agentString )

    # The class instance configuration information is supplied in an XML file
    @staticmethod  # called without first-argument class
    def CreateFromXMLFile( accessXMLfile, agentString="" ):
        global __mysteryString

        # obtain access information from the XML file
        parser = xml.sax.make_parser()
        parser.setFeature( "http://xml.org/sax/features/namespaces", True)
        handler = API.__accessInstanceHandler()
        parser.setContentHandler( handler )
        try:
            with open( accessXMLfile, "r" ) as fileIn:
                parser.parse( fileIn )
        except IOError, (errno, strerror):
            raise FileError( "I/O error(%s): %s" % (errno, strerror) )
        except xml.sax.SAXParseException:
            raise FileError( "File does not parse as well-formed XML: %s"\
                             % accessXMLfile)

        # the following cannot be distilled into a common call because one
        # needs to make the instance of the class before calling a method
        with threading.Lock(): # make access to changing global thread-safe
            __mysteryString = "CraneTradeshiftAPIMysteryString"
            api = API( )
            __mysteryString = ""
        return api.__RawCreateFromStrings(handler._baseURI, handler._tenantId,
                                          handler._key, handler._keySecret,
                                          handler._token, handler._tokenSecret,
                                          agentString)

    # the parsing of an access XML file with credentials found in attributes
    class __accessInstanceHandler( xml.sax.handler.ContentHandler ):
        def __init__( self ):
            self._baseURI = None
            self._tenantId = None
            self._key = None
            self._keySecret = None
            self._token = None
            self._tokenSecret = None
    
        def startElementNS( self, ( uri, name ), qname, attrs):
            s_uri = "" if uri == None else uri
    
            if self._baseURI != None:
               raise ValueError("Unexpected element for access file: "+\
                     "{%s}%s (was expecting the document element to be empty" \
                     % ( s_uri, name ))
                
            if s_uri != "" or name != "CraneTradeshiftAPIAccess":
               raise ValueError("Unexpected document element for access "+\
                     "file: {%s}%s (was expecting {}CraneTradeshiftAPIAccess)"\
                     % ( s_uri, name ))
    
            errors = ""
            for ( ( uri, name ), value ) in attrs.items():
                if   uri == None and name == "baseURI": self._baseURI = value
                elif uri == None and name == "tenantId": self._tenantId = value
                elif uri == None and name == "key": self._key = value
                elif uri == None and name == "keySecret": \
                                                        self._keySecret = value
                elif uri == None and name == "token": self._token = value
                elif uri == None and name == "tokenSecret": \
                                                      self._tokenSecret = value
                else: errors += "\nUnexpected attribute {%s}%s" % \
                        ( uri if uri != None else "", name )
            def checkvalue( value, name ):
                return "\nMissing attribute: {}"+name if value == None else ""
            errors += checkvalue( self._baseURI, "baseURI")
            errors += checkvalue( self._tenantId, "tenantId")
            errors += checkvalue( self._key, "key")
            errors += checkvalue( self._keySecret, "keySecret")
            errors += checkvalue( self._token, "token")
            errors += checkvalue( self._tokenSecret, "tokenSecret")
            if errors != "":
                raise ValueError(errors)

            xml.sax.handler.ContentHandler.startElementNS( self, ( uri, name), 
                                                           qname, attrs )
    
        def characters( self, content ):
            raise ValueError("Unexpected character element for access file:"+\
                     " ""%s"" (was expecting an empty element)" % content)

    # The class instance is instantiated here, but can't be done directly
    # thus requiring one of the two above static methods to be used
    def __init__( self ):
        global __mysteryString
        if __mysteryString != "CraneTradeshiftAPIMysteryString":
            raise NotImplementedError( "One must create the Crane Tradeshift"+\
                     " API instance using either the CreateFromXMLFile() "+\
                     "or CreateFromStrings() method; "+\
                     "Please review the documentation." )

    # Some re-used internal constants
    __namePattern = re.compile('^([^a-zA-Z])')
    __sampleMinidom = xml.dom.minidom.parseString( "<doc/>" )

    # Initialize the class instance, having been created indirectly
    def __RawCreateFromStrings( self, baseURI, tenantId, key, keySecret,
                                      token, tokenSecret, agentString ):
        self.baseURI = baseURI       # remember for reporting
        self.tenantId = tenantId
        self.key = key                 # the access key
        self.keySecret = keySecret     # the access key password
        self.token = token             # the access token
        self.tokenSecret = tokenSecret # the access token password
        self.agentString = agentString if agentString != "" else \
                   "CraneTradeshiftAPI/"+"$Revision: 1.60 $"[11:-2] # the agent

        # confirm non-empty values
        if tenantId is None:
            raise ValueError("The API must be initialized with a tenant ID")
        if self.key is None or self.keySecret is None or \
           self.token is None or self.tokenSecret is None:
            raise ValueError("The API must be initialized with a "+\
                             "key/keySecret/token/tokenSsecret quad")

        # homogenize the URI and site used to access a Tradeshift server 
        uriInfo = re.match('(\s*https?://)?(?P<site>[^/]*)'+\
                           '(?P<base>/.*?)(/?\s*$)', baseURI)
        self.site = uriInfo.group("site").lower()
        self.uri = self.site+uriInfo.group("base")+'/'

        # set up a connection to the server
        self.h = httplib.HTTPSConnection( self.site )
        self.headers = {'X-Tradeshift-TenantId':tenantId}  # the account
        self.headers['User-Agent'] = self.agentString

        # obtain access credentials from consumer key/secret pair
        try:
            self.consumerAccess = oauth2.Consumer( self.key, self.keySecret )
        except:
            print >>sys.stderr,"Unexpected error obtaining consumer access "+\
                               "credentials:", sys.exc_info()[0]
            raise

        # obtain access credentials from token key/secret pair
        try:
            self.tokenAccess = oauth2.Token( self.token, self.tokenSecret )
        except:
            print >>sys.stderr,"Unexpected error obtaining token access "+\
                               "credentials:", sys.exc_info()[0]
            raise

        return self

#============
#
# Class instance use

    # Access the Tradeshift server with a REST request
    def rawDOM( self, actionString, resourceString, content="", contentType="",
                responseType="", dataType=xml.dom.minidom.Document ):
        """
        A raw call to the API with an assumed data type of an XML Mini DOM
        """
        return self.raw( actionString, resourceString, content, contentType,
                         responseType, dataType )

    # Access the Tradeshift server with a REST request
    def raw( self, actionString, resourceString, content="", contentType="",
             responseType="", dataType=dict ):
        """
        A raw call to the API with an assumed data type of Python dictionary
        """
        # check action
        action = actionString.upper()
        if action not in ( "GET", "DELETE", "PUT", "POST" ):
            raise ValueError, 'Unexpected action: "%s"' % actionString

        # check resource
        if resourceString[0] == '/': resourceString = resourceString[1::]
        url = 'https://'+self.uri+resourceString

        # check content and massage if necessary
        if action in ( "PUT", "POST" ):
            # translate a DOM instance argument into a raw XML string
            if type(content) == type( API.__sampleMinidom ):
                content = content.toxml()
                contentType = "text/xml"
        else: # assume content unneeded for "GET" and "DELETE"
            content = ""
            contentType = ""
                
        # check types as being valid for each construct
        if not contentType in ("text/xml","application/json","text/plain",""):
            raise ValueError, 'Unexpected content type: "%s"' % contentType
        if not responseType in ("text/xml","application/json","", dict):
            raise ValueError, 'Unexpected response type: "%s"' % responseType
        if not dataType in ("text/xml","application/json","text/plain",
           "application/pdf", "text/html", "", dict, xml.dom.minidom.Document):
            raise ValueError, 'Unexpected data type: "%s"' % dataType

        # access the server with credentials
        try:
            # set up the request's authorization as a header string;
            # Use "None" for token as this is 2-legged not 3-legged OAuth
            request = oauth2.Request.from_consumer_and_token(
                           self.consumerAccess, self.tokenAccess, action, url )
            request.sign_request( oauth2.SignatureMethod_HMAC_SHA1(),
                                  self.consumerAccess, self.tokenAccess )
            authString = "" # build up the string of all request parameters
            for (name, value) in request.iteritems(): # one at a time for all
                authString += ',%s="%s"' % ( name, oauth2.escape( value ) )
            authString = "OAuth "+authString[1::] # preface without first comma
            
            # set up the request information
            recordRequest = {}
            recordRequest["uri"]=url
            recordRequest["action"]=action
            # set up the HTTP headers
            recordRequest["headers"] = {}
            recordRequest["headers"].update( self.headers )
            recordRequest["headers"]["Authorization"]=authString
            # prep as required the content being sent
            if action in ( "PUT", "POST" ):
                # JSON content expected for PUT or POST when given as Python
                if contentType=="":
                    content = json.dumps( content )
                # what format of data is being sent to the API?
                recordRequest["headers"]["Content-type"] = \
                   contentType if ( contentType=="text/xml" or \
                                    contentType=="text/plain" ) \
                               else "application/json"
                # how long is the content?
                recordRequest["headers"]["Content-length"]=len(content)
            # what format is expected back from the API? any if not specified
            if dataType == dict:
                usedataType = "application/json, text/xml, text/plain, "+\
                                  "application/pdf, text/html"
            elif dataType == "": 
                usedataType = "text/xml, application/json, text/plain, "+\
                                  "application/pdf, text/html"
            # when XML is specifically requested, allow plain and convert it
            elif dataType in ( "text/xml", xml.dom.minidom.Document ):
                usedataType = "text/xml, text/plain"
            else:
                usedataType = dataType
            recordRequest["headers"]["Accept"] = usedataType
        except NameError:
            print >>sys.stderr,"Unexpected error with API access:", \
                               url, sys.exc_info()
            raise AccessError

        # do the actual request
        self.h.request( recordRequest["action"], 
                        recordRequest["uri"],content,
                        recordRequest["headers"] )
        # encode the response for the return values
        response = self.h.getresponse()
        recordResponse = { 'status':"%d"%response.status, 
                           'reason':response.reason,
                           'headers':{}}
        recordType = ""
        for ( name, value ) in response.getheaders():
            recordResponse['headers'][ name ] = value
            if name == "content-type": recordType = value

        # deal with the content that came back
        content = response.read()
        if dataType in ( "", xml.dom.minidom.Document ) \
                    and recordType == "text/xml" and content != "": 
            # convert the XML returned into an MiniDOM Document instance
            try:
                content = xml.dom.minidom.parseString(content)
            except:
                print >>sys.stderr,"Problem parsing returned XML:", \
                    url, sys.exc_info()
                raise AccessError
        elif dataType in ( "", dict ) and recordType == "application/json":
            content = json.loads( content )
        elif dataType in ( "", dict ):
            pass # default format accepted so simply leave it as a string
        elif dataType == "text/xml" and recordType == "text/plain":
            # specifically asking for a plain response to be translated to XML
            content = '<?xml version="1.0"?>' + \
                      '<c:CraneTradeshiftAPIText ' + \
                      'xmlns:c="http://www.CraneSoftwrights.com/ns/TS-api">' +\
                      API.__xmlEscape(content) + '</c:CraneTradeshiftAPIText>'
            # override returned parameters with translated parameters
            recordResponse['headers']['content-type']="text/xml"
            recordResponse['headers']['content-length']=len(content)
        elif dataType != recordType:
            raise AccessError,'Requested return type of "%s"' % dataType+\
                              ' returned as type "%s": ' % recordType + content

        # deal with the information that went and came back
        response = { 'request':recordRequest, 'response':recordResponse }
        
        if responseType == "application/json":
            response = json.dumps( response )
        elif responseType == "text/xml":
            # format response details as XML for downstream processing
            response = '<?xml version="1.0"?>\n' + \
                   '<CraneTradeshiftAPI library="%s">\n' % VERSION + \
                   API.__xmlText( " ","request",recordRequest ) + \
                   API.__xmlText( " ","response",recordResponse ) + \
                   '</CraneTradeshiftAPI>\n'

        # everything now ready to return
        return ( response, content )

#============
#
# Convenience function

    # Determine the status from an response object
    @staticmethod  # called without first-argument class
    def StatusFromResponse( response ):
        try:
            status = response["response"]["status"]
        except:
            try:
                status = json.loads( response )["response"]["status"]
            except:
                try:
                   parser = xml.sax.make_parser()
                   parser.setFeature("http://xml.org/sax/features/namespaces",
                                     True)
                   handler = API.__responseHandler()
                   parser.setContentHandler( handler )
                   parser.parse( cStringIO.StringIO(response) )
                   status = handler._status
                except ValueError as e:
                   raise e
                except:
                   raise ValueError("Unrecognized information structure")
        return status

    class __responseHandler( xml.sax.handler.ContentHandler ):
        def __init__( self ):
            self._status = ""
            self._getStatus = False
            self._documentElement = False
    
        def startElementNS( self, ( uri, name ), qname, attrs):
            s_uri = "" if uri == None else uri
    
            if not self._documentElement:
                self._documentElement = True
                if s_uri != "" or name != "CraneTradeshiftAPI":
                   raise ValueError("Unexpected document element for info "+\
                         "file: {%s}%s (was expecting {}CraneTradeshiftAPI)"\
                         % ( s_uri, name ))

            if s_uri=="" and name == "status":
                self._getStatus = True

            xml.sax.handler.ContentHandler.startElementNS( self, ( uri, name), 
                                                           qname, attrs )
    
        def characters( self, content ):
            if self._getStatus: self._status += content

        def endElementNS( self, ( uri, name ), qname ):
            s_uri = "" if uri == None else uri
            if s_uri=="" and name == "status":
                self._getStatus = False

#============
#
# Support functions and exceptions

    # compose the string to show when an instance is printed using "print"
    def __str__(self):
        return '{ CraneTradeshiftAPI_baseURI:"%s"'%self.baseURI+';'+\
                ' CraneTradeshiftAPI_tenantId:"%s"'%self.tenantId+';'+\
                ' CraneTradeshiftAPI_key:"%s"'%self.key+';'+\
                ' CraneTradeshiftAPI_secret:'+'(not exposed);'+\
                ' CraneTradeshiftAPI_agentString:"%s"'%self.agentString+' }'

    # emit XML element syntax with the given name and a string of attributes
    @staticmethod  # called without first-argument class
    def __xmlEscape( text ):
        return unicode(text).replace('&','&amp;').\
               replace('<','&lt;').replace(']]>',']]&gt;')

    @staticmethod  # called without first-argument class
    def __xmlText( prefix, name, children, attrs="" ): 
        ret = "%s<%s%s>\n" % ( prefix, name, attrs )
        if type(children) == type( {} ):
            for each in children.keys():
                # each member is its own element, indented by prefix and space
                thisname = API.__namePattern.sub('_\\1',each)
                thischild = children[each]
                thistype = type(thischild)
                if thistype in ( type({}), type([]) ):
                    # nested dictionary within the dictionary
                    ret += API.__xmlText(prefix+" ", thisname, thischild)
                else:
                    ret += "%s <%s>%s</%s>\n" %\
                     ( prefix, thisname, API.__xmlEscape(thischild), thisname )

        elif type(children) == type( [] ):
            for ( name, value ) in children:
                # each member is its own element, indented by prefix and space
                thisname = API.__namePattern.sub('_\\1',name)
                if type(value) in ( type({}), type([]) ):
                    # nested dictionary within the dictionary
                    ret += __xmlText( prefix+" ", thisname, value )
                else:
                    # just a string
                    ret += "%s <%s>%s</%s>\n" %\
                        ( prefix, thisname, API.__xmlEscape(value), thisname )
                
        ret += "%s</%s>\n" % ( prefix, name )
        return ret
    
class FileError( RuntimeError ):
    """Generic access problem with file calls"""

    def __init__(self, msg='CraneTradeshiftAPI file access error occurred.'):
        self._msg = msg

    def __str__(self):
        return self._msg

class AccessError( RuntimeError ):
    """Generic access problem with HTTP calls"""

    def __init__(self, msg='CraneTradeshiftAPI access error occurred; '+\
                           'See above for message'):
        self._msg = msg

    def __str__(self):
        return self._msg

# Miscellaneous globals

__mysteryString = "" # this needs to be set to a mystery value in order to work
                     # but this has to be done in a thread-protected fashion

###############################################################################
#
# Command-line access to the API

class Main:
    """
CraneTradeshiftAPI.py $Revision: 1.60 $ $Date: 2013/04/13 21:00:21 $

Use:  python  CraneTradeshiftAPI.py  {flags}  {arguments}

Optional flags:

  -? or --help = present this string to standard error and ignore 
                 all other arguments and return a zero return code
  -r {filename} or --response {filename} = redirect response information to
                                           file instead of standard error port
  -d {filename} or --data {filename} = redirect data information to file
                                         instead of standard data port (XML
                                         syntax used when response isn't plain)
  -pr {string} or --prolog-response {string} = inject XML prolog into response
                                               file
  -pd {string} or --prolog-data {string} = inject XML prolog into data file
  -t {type} or --type {type} = text/xml (default), text/plain, application/json
                               data type for content, response and data
                               data ("" or - (hyphen) for Python structures)
  -tr {type} or --type-response {type} = data type for response data
  -td {type} or --type-data {type} = data type for data data
  -tc {type} or --type-content {type} = data type for PUT/POST content

Arguments: four positional arguments (fourth is for PUT or POST only, and when
           absent or hyphen, the standard input is used for the sent content):

  credentialsXMLfile  GET|DELETE|PUT|POST  resource  {PUT-POST-file}

Exit return codes:
  -1 = API error return (status code is not in the 200-299 range)
   0 = no problem (and status code is in the 200-299 range)
   1 = execution problem or argument problem or runtime exception
"""
    pass

if __name__=="__main__":
    import string # Common string operations
    import re     # Regular expression operations
    import os     # Miscellaneous operating system interfaces
    import sys    # System-specific parameters and functions

    # Argument processing
    typeResponse = typeContent = typeData = "text/xml"
    badopt = False
    responseFilename = ""
    dataFilename = ""
    responsePrologue = ""
    dataPrologue = ""
    while len( sys.argv ) > 1 and \
          ( sys.argv[1][0] == '/' or sys.argv[1][0] == '-' ):
        opt = sys.argv[1][1:]
        if opt == '?' or opt == '-help':
            print >>sys.stderr,Main.__doc__
            sys.exit( 0 )
        #elif opt == 'd' or opt == '-debug':  _API__debug = True
        elif opt in ( 'r','-response' ) and len( sys.argv ) >= 2:
            responseFilename = sys.argv[2]
            sys.argv[2:3] = [] # remove argument to argument
        elif opt in ( 'd','-data' ) and len( sys.argv ) >= 2:
            dataFilename = sys.argv[2]
            sys.argv[2:3] = [] # remove argument to argument
        elif opt in ( 'pr','-prolog-response' ) and len( sys.argv ) >= 2:
            responsePrologue = sys.argv[2]
            sys.argv[2:3] = [] # remove argument to argument
        elif opt in ( 'pd','-prolog-data' ) and \
               len( sys.argv ) >= 2:
            dataPrologue = sys.argv[2]
            sys.argv[2:3] = [] # remove argument to argument
        elif opt in ( 't','-type' ) and len( sys.argv ) >= 2:
            typeResponse = typeContent = \
            typeData = "" if sys.argv[2] in ( '""','-' ) else sys.argv[2]
            if typeResponse == "dict": typeResponse = dict
            if typeData == "dict": typeData = dict
            sys.argv[2:3] = [] # remove argument to argument
        elif opt in ( 'tr','-type-response' ) and len( sys.argv ) >= 2:
            typeResponse = "" if sys.argv[2] in ( '""','-' ) else sys.argv[2]
            if typeResponse == "dict": typeResponse = dict
            sys.argv[2:3] = [] # remove argument to argument
        elif opt in ( 'td','-type-data' ) and len( sys.argv ) >= 2:
            typeData = "" if sys.argv[2] in ( '""','-' ) else sys.argv[2]
            if typeData == "dict": typeData = dict
            sys.argv[2:3] = [] # remove argument to argument
        elif opt in ( 'tc','-type-content' ) and len( sys.argv ) >= 2:
            typeContent = "" if sys.argv[2] in ( '""','-' ) else sys.argv[2]
            sys.argv[2:3] = [] # remove argument to argument
        else:
            print >>sys.stderr,'Option "%s" not recognized' % opt
            badopt = True
        sys.argv[ 1:2 ] = [] # remove argument
    
    fileInName = None
    action = sys.argv[2].upper() if len(sys.argv)>2 else ""

    if action in ( "PUT","POST" ) and \
       ( len( sys.argv )==4 or ( len( sys.argv )==5 and sys.argv[4]=='-' ) ):
        # the standard input is being used as the source, not a file
        fileInName = "<stdin>"
        fileIn = sys.stdin
    elif len( sys.argv ) < 4 or len( sys.argv ) > 5 or \
       ( len( sys.argv ) == 5 and not action in ( "PUT", "POST" )   ) or \
       ( len( sys.argv ) == 4 and not action in ( "GET", "DELETE" ) ) or \
        badopt:
        # cannot proceed as requested by user
        print >>sys.stderr,Main.__doc__
        sys.exit(1)

    if len( sys.argv ) == 5: # the input is a file
        fileInName = sys.argv[4]
        try: # opening the input file
            fileIn = open( fileInName, "r" )
        except IOError, (errno, strerror):
            print >>sys.stderr,"I/O error during open of input (%s): %s" % \
                               ( errno, strerror )
            sys.exit(1)
        except:
            print >>sys.stderr,"Unexpected error:",sys.exc_info()[0]
            sys.exit(1)

    content = ""
    if fileInName:
        try: # reading the input
            content = fileIn.read()
            fileIn.close()
        except IOError, (errno, strerror):
            print >>sys.stderr,"I/O error during read/close of input (%s): %s"\
                               % ( errno, strerror )
            sys.exit(1)
        except:
            print >>sys.stderr,"Unexpected error:",sys.exc_info()[0]
            sys.exit(1)
    
    # set up credentials
    
    #t= API.CreateFromStrings( "baseURI","tenantID","key","secret" )#by strings
    t = API.CreateFromXMLFile( sys.argv[1] )                        #by a file
    
    # call the API obtaining the raw return information
    ( response, data ) = t.raw( actionString=action, 
                                resourceString=sys.argv[3], 
                                content=content,
                                contentType=typeContent,
                                responseType=typeResponse,
                                dataType=typeData)
    
    # return the results; injecting prologue information if requested
    prologuePattern = re.compile( '^(?P<decl><\?xml [^<]*\?>)?(?P<rest>.+)',
                                  re.DOTALL)
    if sys.platform == "win32": # default is not binary which messes up PDF
        import msvcrt # Useful routines from the MS VC++ runtime
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
        msvcrt.setmode(sys.stderr.fileno(), os.O_BINARY)
    responseHandle = sys.stderr if responseFilename=="" else \
                                                   open(responseFilename, 'wb')
    outHandle = sys.stdout if dataFilename=="" else open(dataFilename,'wb')
    
    if responsePrologue != "" and typeResponse == "text/xml":
        details = prologuePattern.match(response)
        decl = details.group("decl")
        responseHandle.write( ( decl+"\n" if decl else "" ) \
                           +responsePrologue+details.group("rest") )
    else:
        responseHandle.write( str( response ) )
    
    if dataPrologue != "" and typeData == "text/xml":
        details = prologuePattern.match(data)
        decl = details.group("decl")
        outHandle.write( ( decl+"\n" if decl else "" ) \
                          +dataPrologue+details.group("rest") )
    else:
        outHandle.write( str( data ) )
    
    # done; parse the end result status
    status = API.StatusFromResponse( response )
    
    sys.exit( 0 if status[0] == '2' else -1 ) # exit of 1 for execution problem

# end of file
