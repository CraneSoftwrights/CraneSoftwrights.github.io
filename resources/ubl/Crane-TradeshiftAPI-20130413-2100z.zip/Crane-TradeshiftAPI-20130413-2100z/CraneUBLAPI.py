"""
CraneUBLAPI.py $Revision: 1.8 $ $Date: 2013/04/13 21:00:20 $

A Python language library of constants and classes related to the
OASIS Universal Business Language (UBL).

Dependencies: xpath   # from http://code.google.com/p/py-dom-xpath/

Note: while this library is distributed as part of Crane's API interface to 
      Tradeshift, facilities found herein are in no way tied to that interface.
      The dispatchNewestInvoiceSample.py application briefly illustrates the
      use of this library.

Contents: 

(1) Some useful constants when working with UBL documents:

    CAC # the namespace for all Common Aggregate Components
    CBC # the namespace for all Common Basic Components
    EXT # the namespace for all Common Extension Components
    SIG # the namespace for apex Signature Extension element
    SAC # the namespace for all Signature Extension Aggregate Components
    SBC # the namespace for all Signature Extension Basic Components
        # e.g.  from CraneUBLAPI import *
        # e.g.  (when using xml.dom.minidom)
        #       paymentMeans = x.getElementsByTagNameNS(CAC,"PaymentMeans")

    # get the version of this API implementation
    print CraneUBLAPI.VERSION

(2) UBLXPathContext class:

    An extension of the py-dom-xpath class XPathContext pre-loaded with
    UBL namespace prefix bindings.

    Please see the API class documentation below for usage details or print
    from interactive Python:
    
          python
          >>> import CraneUBLAPI
          >>> print CraneUBLAPI.UBLXPathContext.__doc__
          >>> quit()

Future work:
 - create a UBL document from a Python structure of invoice information

Copyright (C) - Crane Softwrights Ltd.
              - http://www.CraneSoftwrights.com/links/res-ts.htm

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

- Redistributions of source code must retain the above copyright notice,
  this list of conditions and the following disclaimer.
- Redistributions in binary form must reproduce the above copyright notice,
  this list of conditions and the following disclaimer in the documentation
  and/or other materials provided with the distribution.
- The name of the author may not be used to endorse or promote products
  derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN
NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Note: for your reference, the above is the "Modified BSD license", this text
      was obtained 2003-07-26 at http://www.xfree86.org/3.3.6/COPYRIGHT2.html#5

THE AUTHOR MAKES NO REPRESENTATION ABOUT THE SUITABILITY OF THIS CODE FOR ANY
PURPOSE.

Revision history (major features only; minor issues not recorded):

Release: 1.8 - 20130413-2100z - Arg check; document exposition
Release: 1.6 - 20110606-0150z - Optional args; add fullpath
Release: 1.4 - 20110528-1810z - Fix version number; document example
Release: 1.2 - 20110528-1640z - Add XPathContext support
Release: 1.1 - 20101030-1920z - Initial version
"""

# what is exposed in this API?

__all__ = [ "CAC", "CBC", "EXT", "SIG", "SAC", "SBC", "UBLXPathContext" ]

VERSION = "$Revision: 1.8 $"[11:-2]

###############################################################################
#
# useful constants

CBC ="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
CAC ="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
EXT ="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"
SIG ="urn:oasis:names:specification:ubl:schema:xsd:CommonSignatureComponents-2"
SAC=\
  "urn:oasis:names:specification:ubl:schema:xsd:SignatureAggregateComponents-2"
SBC ="urn:oasis:names:specification:ubl:schema:xsd:SignatureBasicComponents-2"

###############################################################################
#
# finding constructs in a UBL instance

import xpath               # from http://code.google.com/p/py-dom-xpath/
import xml.dom.minidom     # standard Python library

class UBLXPathContext( xpath.XPathContext ):
    """
An extension of the py-dom-xpath class pre-loaded with UBL common-library
namespaces ready to use.

    - this extends xpath.XPathContext() with preloaded namespaces for UBL
    - regardless of the namespace prefixes used in the UBL instance,
      expressions are obliged to use the following assumptions:

       Name = name in the namespace of the document element
       cac:Name = Name in the Common Aggregate Components namespace
       cbc:Name = Name in the Common Basic Components namespace
       ext:Name = Name in the Common Extension Components namespace
       sig:Name = Name in the Signature Components apex namespace
       sac:Name = Name in the Signature Aggregate Components namespace
       sbc:Name = Name in the Signature Basic Components namespace

    - see http://py-dom-xpath.googlecode.com/svn/trunk/doc/index.html
      - note three differences in this library compared to py-dom-xpath:
        (1) - an instance of this class must be initialized with the UBL 
              document in order for the default namespace to be bound to the
              namespace of the document element of the UBL document; and
        (2) - all of the shadow methods default an absent node argument to
              be the document node
        (3) - there are additional methods described below
"""

    def __init__( self, document, **kwargs ):
        self.document = document
        # first check to ensure the correct argument type is supplied
        if not( isinstance( document, xml.dom.minidom.Document ) ):
            self.document = xml.dom.minidom.parseString(
                                                     "<NotAMiniDOMDocument/>" )
        try:
            xpath.XPathContext.__init__( self, self.document, **kwargs )
        except:
            self.document = xml.dom.minidom.parseString(
                                              "<ProblemWithMiniDOMDocument/>" )
            xpath.XPathContext.__init__( self, self.document, **kwargs )
        self.namespaces['cac'] = CAC
        self.namespaces['cbc'] = CBC
        self.namespaces['ext'] = EXT
        self.namespaces['sig'] = SIG
        self.namespaces['sac'] = SAC
        self.namespaces['sbc'] = SBC
        
    def __str__( self ):
        return self.document.toxml()
        
    # shadow the XPath library calls with the document node being the default
    # node if the call does not supply a node
    def find( self, expr, node=None, **kwargs ):
        return xpath.XPathContext.find( self, expr,
                                        node if node else self.document,
                                        **kwargs )

    def findnode( self, expr, node=None, **kwargs ):
        return xpath.XPathContext.findnode( self, expr, 
                                            node if node else self.document,
                                            **kwargs )

    def findvalue( self, expr, node=None, **kwargs ):
        return xpath.XPathContext.findvalue( self, expr,
                                             node if node else self.document,
                                             **kwargs )

    def findvalues( self, expr, node=None, **kwargs):
        return xpath.XPathContext.findvalues( self, expr,
                                              node if node else self.document,
                                              **kwargs )

    # unique to this library and not a part of the XPath library
    def fullpath( self, node ):
        """ calculate the path to the node """
        documentElement = True  # no predicate needed for the document element
        path = ""               # build up the path from nothing
        # by walking down the ancestors
        for ancestor in self.find( "ancestor-or-self::*", node ):
            name = ancestor.nodeName
            # add this step to the path
            if documentElement:       # there are no siblings
                path += "/%s" % name
                documentElement = False
            else:                     # there may very well be siblings
                # noting the count of siblings of the same name
                path += "/%s[%d]" % ( name, 1 + self.find( \
               "count(preceding-sibling::*[name(.)='%s'])" % name, ancestor ) )
        return path

###############################################################################
#
# Debug and illustration only 

if __name__=="__main__":
    doc = xml.dom.minidom.parseString(
            """<ca:Party xmlns:ca="%s" xmlns:cb="%s">
               <ca:PartyIdentification>
               <cb:ID>x</cb:ID><cb:ID>y</cb:ID>
               </ca:PartyIdentification>
               </ca:Party>""" % ( CAC, CBC ) )
    print "Debug and illustration (expecting 'y' and then 'x'):"
    # create an addressing object
    ubl = UBLXPathContext( doc)
    # example of an absolute address (from the top of the document)
    print ubl.findvalue( '/*/*/cbc:ID[2]' )
    # jumping into the document
    pi = ubl.find( "/*/cac:PartyIdentification" )
    # example of a relative address (from the jump location)
    print ubl.findvalue( 'cbc:ID[1]', pi[0] )
    # exposing the path to a node
    print ubl.fullpath( ubl.find( 'cbc:ID[2]', pi[0] )[0] )
    
# end of file
