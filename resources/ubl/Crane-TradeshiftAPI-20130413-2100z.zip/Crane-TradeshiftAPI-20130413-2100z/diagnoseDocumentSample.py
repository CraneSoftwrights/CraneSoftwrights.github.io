#. Illustration of the use of the Python API:
#
#     diagnose the validity of a putative new document to be added
#
#     - steps to invoke this program:
#
#     1 - download a document and its metadata from the account
#     2 - from the metadata determine the profile identifier
#     3 - change the invoice number to an unused invoice number
#     4 - invoke this sample using the profile identifier and edited document
#         as invocation arguments (in addition to the access credentials)
#
# $Revision: 1.1 $$Date: 2013/04/13 19:29:23 $

import CraneTradeshiftAPI
import sys
from xml.dom.minidom import parse

def retString( ret, response ):
    return 'Problem "%s" accessing API\n%s' % ( ret, response.__str__() )

# ensure the command line argument is available
if len(sys.argv) != 4:
    print >>sys.stderr,"Exactly three arguments needed: "+\
                       "the access credentials filename, "+\
                       " the profile identifier and the document filename"
    sys.exit(1)

# get the document to be validated
doc = parse( sys.argv[3] )

# create an instance of the API to use
t = CraneTradeshiftAPI.API.CreateFromXMLFile( sys.argv[1] )

( response, diagnostic ) = t.raw( "post", 
                       "external/documents?documentProfileId=%s" % sys.argv[2],
                                  doc, dataType="application/json" )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret == "204":
    print "Successful validation response; no information returned"
elif ret == "400":
    print diagnostic
else:
    raise Exception,retString( ret, response )

# end of file