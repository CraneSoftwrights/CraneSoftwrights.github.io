#. Illustration of the use of the Python API:
#
#     display information from the newest draft document in storage
#
# $Revision: 1.1 $$Date: 2013/04/13 19:29:02 $

import CraneTradeshiftAPI
import CraneUBLAPI
import uuid
import re
import sys
import datetime

def retString( ret, response ):
    return 'Problem "%s" accessing API\n%s' % ( ret, response.__str__() )

# ensure the command line argument is available
if len(sys.argv) != 2:
    print >>sys.stderr,"Exactly one argument needed: "+\
                       "the access credentials filename"
    sys.exit(1)

# create an instance of the API to use
t = CraneTradeshiftAPI.API.CreateFromXMLFile( sys.argv[1] )

# get the newest invoice
( response, docList ) = t.raw( "get", 
                               "external/documents?type=invoice&limit=1&stag=draft" )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "200": raise Exception,retString(ret,response)

# these values will be the same for every loop
count = docList['itemCount']
if count == 0:
    print "No invoice found to duplicate."
    sys.exit(0)

# only need first document; default is descending edited date order
newest = docList['Document'][0]
id = newest['DocumentId']
profile = newest['DocumentType']['documentProfileId']

# get a copy of the document
( response, docNewest ) = t.rawDOM( "get", 
                                    "external/documents/%s" % id )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "200": raise Exception,retString( ret, response )

# find the old identifier text
ubl = CraneUBLAPI.UBLXPathContext( docNewest )

currentID = ubl.findvalue( "/*/cbc:ID" )
currentUUID = ubl.findvalue( "/*/cbc:UUID" )
currentIssueDate = ubl.findvalue( "/*/cbc:IssueDate" )
currentTotal = ubl.findvalue("/*/cac:LegalMonetaryTotal/cbc:PayableAmount")

def showPartyInfo( party ):
  print "  Name: ",ubl.findvalue( "cac:PartyName/cbc:Name", party )
  print "  ID: ",ubl.findvalue( "cac:PartyIdentification/cbc:ID", party )

print "Invoice identifier: ",currentID
print "Document identifier: ",id
print "Invoice date: ",currentIssueDate
print "Payable amount: ",currentTotal
print "Customer info:"
showPartyInfo( ubl.findnode( "/*/cac:AccountingCustomerParty/cac:Party" ) )
print "Supplier info:"
showPartyInfo( ubl.findnode( "/*/cac:AccountingSupplierParty/cac:Party" ) )

# end of file
