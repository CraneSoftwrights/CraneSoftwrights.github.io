#. Illustration of the use of the Python API:
#
#     duplicate the newest invoice document in storage
#
# $Revision: 1.10 $$Date: 2013/04/13 19:30:16 $

import CraneTradeshiftAPI
import CraneUBLAPI
import uuid
import re
import sys
import datetime

def retString( ret, response ):
    return 'Problem "%s" accessing API\n%s' % ( ret, response.__str__() )

# ensure the command line argument is available
if len(sys.argv) != 2:
    print >>sys.stderr,"Exactly one argument needed: "+\
                       "the access credentials filename"
    sys.exit(1)

# create an instance of the API to use
t = CraneTradeshiftAPI.API.CreateFromXMLFile( sys.argv[1] )

# get the newest invoice
( response, docList ) = t.raw( "get", 
                               "external/documents?type=invoice&limit=1" )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "200": raise Exception,retString(ret,response)

# these values will be the same for every loop
count = docList['itemCount']
if count == 0:
    print "No invoice found to duplicate."
    sys.exit(0)

# only need first document; default is descending edited date order
newest = docList['Document'][0]
id = newest['DocumentId']
profile = newest['DocumentType']['documentProfileId']

# get a copy of the document
( response, docNewest ) = t.rawDOM( "get", 
                                    "external/documents/%s" % id )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "200": raise Exception,retString( ret, response )

# find the old identifier text
ubl = CraneUBLAPI.UBLXPathContext( docNewest )

currentIDElement = ubl.findnode( "/*/cbc:ID" )
currentIDText = currentIDElement.firstChild
# create new identifier text based on old and with a date/time
timestamp = datetime.datetime
oldIDText = re.sub("(.+?)(-COPYDATE-.*$)?","\\1",currentIDText.data )
newIDText = docNewest.createTextNode( \
             oldIDText + "-COPYDATE-%sZ" % timestamp.utcnow().isoformat() )
currentIDElement.replaceChild( newIDText, currentIDText )
currentIDText.unlink() # old node not needed

# Determine a new unique identifier
newUUID = uuid.uuid4()

# put it out
print "Duplicating document %s (invoice)\n   creating document %s ..." % \
      ( id, newUUID ), 
( response, putLast ) = t.raw( "put", 
                               "external/documents/%s?documentProfileId=%s" % \
                                      ( newUUID, profile ), docNewest )
print putLast
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "204": raise Exception,retString( ret, response )

# end of file
