#. Illustration of the use of the Python API:
#
#     delete the newest document in storage
#
# $Revision: 1.8 $$Date: 2013/04/13 19:30:13 $

import CraneTradeshiftAPI
import sys

def retString( ret, response ):
    return 'Problem "%s" accessing API\n%s' % ( ret, response.__str__() )

# ensure the command line argument is available
if len(sys.argv) != 2:
    print >>sys.stderr,"Exactly one argument needed: "+\
                       "the access credentials filename"
    sys.exit(1)

# create an instance of the API to use
t = CraneTradeshiftAPI.API.CreateFromXMLFile( sys.argv[1] )

# get the newest invoice
( response, docList ) = t.raw( "get", "external/documents?limit=1" )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "200": raise Exception,retString(ret,response)

# these values will be the same for every loop
count = docList['itemCount']
if count == 0:
    print "No document found to delete."
    sys.exit(0)

# only need first document; default is descending edited date order
newest = docList['Document'][0]
id = newest['DocumentId']
docType = newest['DocumentType']['type']
    
# delete that document
print "Deleting document %s (%s) ..." % ( id, docType ) 
( response, docNewestDelete ) = t.raw( "delete", "external/documents/%s" % id )
ret = CraneTradeshiftAPI.API.StatusFromResponse( response )
if ret != "200": raise Exception,retString( ret, response )

# end of file
