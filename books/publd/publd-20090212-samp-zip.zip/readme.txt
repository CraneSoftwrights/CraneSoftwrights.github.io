Practical Universal Business Language Deployment - readme.txt
================================================

This ZIP file is in support of the Crane PDF publication titled "Practical
Universal Business Language Deployment" available for purchase through:

  http://www.CraneSoftwrights.com/training/

===============
$Id: book-readme.txt,v 1.1 2007/03/02 01:39:39 G. Ken Holman Exp $
