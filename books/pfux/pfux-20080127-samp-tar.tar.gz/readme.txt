Practical Formatting Using XSL-FO - readme.txt
=================================

Overview:
--------

Step 1: - determine the subdirectory in which the sample environment
          will be used
        - unpack the sample files

Step 2: - determine the processor(s) you will be using for the samples
        - unpack and/or install the processor

Step 3: - from an MSDOS command line navigate to the sample environment
        - ensure the invocation files reflect your choice in processors
        - test the installation as described below

Note to non-Windows users:
 - the compressed package of exercise files will successfully unzip, though
   the included non-Windows invocation files do not have the execution
   permission bit set (such files are distinguished by having no extension)
 - see the section below on non-Windows environments for details on the
   invocation arguments for Saxon and RenderX

Trouble-shooting guidelines are included at the end of this document.


Unpacking the sample files
==========================

One self-extracting executable contains all of the sample files which
can be stored in any directory on the system you choose (the .exe file
can also be opened as a .zip file, preserving directories, by archiving
tools).  The sample files can be placed in any subdirectory you wish
(it is recommended to create a new subdirectory) and are extracted by
running the command:

  pfux-????????-samp.exe

or

  pfux-????????-samp.zip

or

  pfux-????????-samp.tar.gz

A typical response for the target directory would be something like:

  c:\pfux

When the sample files are installed the following subdirectories are
created:

  prog     - invocation batch files for XSLT processors
  samp     - sample files from text of the training material

The invocation directory contains the generic invocation file "xslt.bat"
and "fo.bat" that are replaced with the desired invocation file for the 
XSLT and XSL-FO processors (respectively) being used (they are delivered
as a copy of "xslsaxon.bat" and "fojavaxep.bat").  For example, to use
the Ibex processor, copy the "fojavaibex.bat" file over top of the
"fo.bat" file.


Obtaining the XSLT processor
----------------------------

Please obtain copies of the two Saxon XSLT processors and load their
respective jar files into the prog\ subdirectory:

For XSLT 1 get Saxon 6.5.5 create:

  c:\ptux\prog\saxon.jar  from   http://saxon.sourceforge.net/#F6.5.5

For XSLT 2 get Saxon-B 9.0 create:

  c:\ptux\prog\saxon9.jar from   http://saxon.sourceforge.net/#F9.0B

You may need to use alternative versions replacing the above after
the date of this readme file.



Running samples with the Antenna House Windows-based XSL-FO processor
=====================================================================

Test the installation by specifying only an FO file without a 
stylesheet:

   Document:    c:\pfux\samp\hellofo.fo
   Stylesheet:  

Press the F5 key or select Formatter/RunFormatter to produce the 
result.

Alternatively one could test the combination of an XML file and
an XSLT stylesheet:

   Document:    c:\pfux\samp\hellofo.xml
   Stylesheet:  c:\pfux\samp\hellofo.xsl

Press the F5 key or select Formatter/RunFormatter to produce the 
result.

Note that well-formedness error messages from the XML processor
used by this tool are not informative.  To check on the
well-formedness of an XML file, see the troubleshooting discussion
below on the use of the "check" batch file.


Running samples with the RenderX or Ibex Java-based XSL-FO processor
====================================================================

Determine the invocation sequence for your XSLT processor and modify
the prog\xslt.bat file to invoke the processor and create the output.

Arguments (in order):

 - source filename
 - stylesheet filename
 - output filename

A number of invocation files for various XSLT processors are already
prepared in the prog\ directory.  Any one of these can just be copied
over top of the prog\xslt.bat file.

The invocation file for XEP assumes that the "/xep" directory is a
sibling of the "/prog" directory; for example "c:\pfux\xep".

The invocation file for Ibex assumes that the "ibex.jar" file is in
the "/prog" directory.


The use of the Java runtimes
============================

To test the presence of a Sun Java runtime on the path, witness the
following result at the command line:

  C:\pfux>java
  Usage: java [-options] class [args...]
			 (to execute a class)
	 or  java -jar [-options] jarfile [args...]
			 (to execute a jar file)

If the Java runtime is not on the path, you will see something like
one of the following error messages:

  C:\pfux>java
  'java' is not recognized as an internal or external command,
  operable program or batch file.

  C:\pfux>java
  The name specified is not recognized as an
  internal or external command, operable program or batch file.

  C:\pfux>java
  Bad command or file name

  C:\pfux>

The Java-based invocation files rely on the Java runtime environment
named "java.exe" being on the system path.  If this is not the case,
you can execute a command similar to the following (remembering to 
use "c:\progra~1" in place of "c:\Program Files"):

  path=%path%;c:\java-directory-name-here\bin


Testing the installation of the sample files
============================================

In the following, the "hellofo" sample FO is run from the sample directory
with the RenderX tool (using other tools will produce different messages
but the same "hellofo.pdf" result):

  C:\pfux\samp>..\prog\fo hellofo.fo hellofo.pdf
  Ensuring FO file doesn't use default namespace...
  Invoking Saxon executable....
  Invoking XEP "hellofo.fo.fo" to "hellofo.fo.pdf"
  (document
  [input hellofo.fo.fo]
  [output hellofo.fo.pdf]
  (S (parse [system-id file:/C:/pfux/samp/hellofo.fo.fo]))
  (I (masters )(sequences (sequence [master-reference bookpage]
  (title )(flow [flow-name bookpage-body]))))
  (F (BkMaker
  (sequence bookpage (flow [page-number 1])
  (static-content [page-number 1])
  )))
  (T (SAX [page-number 1]))
  )
  ----
  done
  	       1 file(s) copied.
  File "hellofo.pdf" created!
  
  C:\pfux\samp>

In the following, the "hellofo" sample XSL is run from the sample directory
with the RenderX tool (using other tools will produce different messages
but the same "hellofo.pdf" result):

  C:\pfux\samp>..\prog\fo hellofo.xml hellofo.xsl hellofo.pdf
  Invoking XSLT for "hellofo.xml" with "hellofo.xsl" to "hellofo.pdf.fo"
  Invoking Saxon executable....
  Ensuring FO file doesn't use default namespace...
  Invoking Saxon executable....
  Invoking XEP "hellofo.pdf.fo.fo" to "hellofo.pdf.fo.pdf"
  (document
  [input hellofo.pdf.fo.fo]
  [output hellofo.pdf.fo.pdf]
  (S (parse [system-id file:/C:/pfux/samp/hellofo.pdf.fo.fo]))
  (I (masters )(sequences (sequence [master-reference bookpage]
  (title )(flow [flow-name bookpage-body]))))
  (F (BkMaker
  (sequence bookpage (flow [page-number 1])
  (static-content [page-number 1])
  )))
  (T (SAX [page-number 1]))
  )
  ----
  done
  	       1 file(s) copied.
  File "hellofo.pdf" created!
  
  C:\pfux\samp>


Configuring the page size
=========================

The environment as unpacked supports the international A4 page dimensions
through the use of the "pages.ent" file in the samp\ subdirectory.  The
subdirectory also contains the files "pages-a4.ent" and "pages-us.ent",
either of which can be copied on top of "pages.ent".  

Thus, to change the environment to produce US letter-sized results, run:

  C:\pfux\samp>copy pages-us.ent pages.ent
          1 file(s) copied.
  C:\pfux\samp>


Troubleshooting
===============

Some users have reported problems unzipping files until they associate
the "zip" file extension with the WinZip application, after which they
don't have the problems they were experiencing.

Some processors give misleading or insufficient error messages.  The
batch file "check.bat" can be used to use the XSLT processor to report
problems with an XML file, or to create an indented version of the file:

  C:\pfux\samp>check hellofo.fo
  Invoking Saxon executable....
  File 'hellofo.fo.chk' created!

  C:\pfux\samp>

Some invocation files need environment variables to be set before they
can be used.  In each case an error is reported that a particular file
cannot be found.  In many cases the problem is that the user set the
environment variable to the directory, but did not include a trailing
subdirectory separator slash at the end of the string.

The message "Not enough environment space for SET variables" indicates
the need to increase the size of the environment space for the command
processor.  This is typically done permanently in one's environment,
but can be done temporarily with the following command to invoke a
temporary environment:

     command /e:4000

When attempting to execute the Java runtime environment or the Windows
.exe files, typical messages when the program cannot be found on the
execution path are as follows:

 - Bad command or file name
 - The name specified is not recognized as an...

To determine the path, one can enter the following to see the directories:

  path

To change the path for the current command line window, enter:

  path=%path%;new-drive-and-directory-here

Note that entering this command on the command line will only change the
path for command line box being used.  To make the change permanent, one
must change the appropriate startup files for your environment.

Note that the path command does not work well when using the directory
named "Program Files" because of the embedded space.  The hidden
equivalent to this is "progra~1", so you must use "c:\progra~1\..."
with the remainder as required.

===============
$Id: book-readme.txt,v 1.11 2008/01/27 18:54:29 G. Ken Holman Exp $
