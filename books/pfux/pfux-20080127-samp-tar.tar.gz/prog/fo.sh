XEP=../xep

if [[ a$3 == a ]]
then
java -cp "$XEP/lib/xep.jar" com.renderx.xep.XSLDriver "-DCONFIG=$XEP/xep.xml" -DXEP2_COMPATIBLE_MODE=false $1 $2
else
sh ../prog/xslt2.sh $1 $2 $3.fo
java -cp "$XEP/lib/xep.jar" com.renderx.xep.XSLDriver "-DCONFIG=$XEP/xep.xml" -DXEP2_COMPATIBLE_MODE=false $3.fo $3.pdf
fi
