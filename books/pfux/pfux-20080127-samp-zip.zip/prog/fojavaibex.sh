if [[ a$3 == a ]]
then
echo Formatting $1 as XSL-FO to PDF $2...
rm $2
java -cp ../prog/ibex.jar -Dibexconfig=../prog/ibexconfig.xml ibex.Run -xml $1 -pdf $2
else
rm $3
sh ../prog/xslt2.sh $1 $2 $3.fo
echo Formatting $3.fo as XSL-FO to PDF $3...
java -cp ../prog/ibex.jar -Dibexconfig=../prog/ibexconfig.xml ibex.Run -xml $3.fo -pdf $3
fi

