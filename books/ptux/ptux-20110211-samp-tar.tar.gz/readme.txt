Practical Transformation Using XSLT and XPath - readme.txt
=============================================

Overview:
--------

Step 1: - determine the subdirectory in which the sample environment
          will be used
        - unpack the sample files

Step 2: - determine the processor(s) you will be using for the samples
        - unpack and/or install the processor

Step 3: - from an MSDOS command line navigate to the sample environment
        - ensure the invocation files reflect your choice in processors
        - test the installation as described below

Trouble-shooting guidelines are included at the end of this document.


Unpacking the sample files
--------------------------

One self-extracting executable contains all of the sample files which
can be stored in any directory on the system you choose.

The sample files can be placed in any subdirectory you wish (it is
recommended to create a new subdirectory) and are extracted by
running the command:

  ptux-????????-samp.exe

or by unzipping the following file preserving the subdirectories:

  ptux-????????-samp.zip

Non-Windows users can access the following archive:

  ptux-????????-samp.tar.gz

When using the self-extracting executable, a typical response for 
the target directory would be something like:

  c:\ptux

When the sample files are installed the following subdirectories are
created:

  prog     - invocation batch files for processors
  samp     - sample files from text of the training material

Obtaining the XSLT processor
----------------------------

Please obtain copies of the two Saxon XSLT processors and load their
respective jar files into the prog\ subdirectory:

For XSLT 1 get Saxon 6.5.5 create:

  c:\ptux\prog\saxon.jar  from   http://saxon.sourceforge.net/#F6.5.5

For XSLT 2 get Saxon-HE 9.3 (or later version) create:

  c:\ptux\prog\saxon9he.jar from   http://saxon.sourceforge.net/#F9.3HE

You may need to use alternative versions replacing the above after
the date of this readme file.


Running the XSLT processor
--------------------------

The invocation directory contains a generic invocation file "xslt.bat" 
that is replaced with the desired invocation file for the processor 
being used (it is delivered as a copy of "xsljavasaxon.bat").

For example, if you wished to use the Xalan processor instead of the
Saxon processor, the following will engage the correct invocation
file:

  cd \xslt\prog
  copy xsljavaxalan.bat xslt.bat

For another example, if you wished to use the Windows-executable Saxon
processor instead of the Java-based Saxon processor, the
following will engage the correct invocation file:

  cd \xslt\prog
  copy xslsaxon.bat xslt.bat

If you plan to run IE6, or the latest MSXML DLL with IE5, there is no
need to work from the command line.  Opening the sample XML file
in the browser will automatically invoke the associated sample
stylesheet.  When using this method, don't forget to refresh the
browser screen after each edit of the sample stylesheet or you will
be improperly examining old results on your screen.


The use of the Java runtime
---------------------------

To test the presence of a Java runtime on the path, witness the
following result at the command line:

  c:\ptux>java
  Usage: java [-options] class [args...]
			 (to execute a class)
	 or  java -jar [-options] jarfile [args...]
			 (to execute a jar file)

If the Java runtime is not on the path, you will see something like:

  c:\ptux>java
  The name specified is not recognized as an
  internal or external command, operable program or batch file.

  c:\ptux>java
  Bad command or file name

  c:\ptux>

The Java-based invocation files rely on the Java runtime environment
named "java.exe" being on the system path.  If this is not the case,
you can execute a command similar to the following:

  path=%path%;C:\java-directory-name-here\bin


Testing the installation of the sample files
----------------------------------------------

In the following, the "hello" sample is run from the sample directory
with the Saxon tool (using other tools will produce different messages
but the identical "hello.htm" result):

   C:\>cd ptux
   
   C:\ptux>cd samp
   
   C:\ptux\samp>..\prog\xslt1 hello.xml hello.xsl hello.htm
   Transforming hello.xml with hello.xsl to hello.htm with XSLT 1.0...
   
   C:\ptux\samp>type hello.htm
   <b><i><u>Hello world.</u></i></b>
   C:\ptux\samp>
   C:\ptux\samp>..\prog\xslt2 hello.xml hello2.xsl hello2.htm
   Transforming hello.xml with hello2.xsl to hello2.htm with XSLT 2.0...
   
   C:\ptux\samp>type hello2.htm
   <b><i><u>Hello world.</u></i></b>
   C:\ptux\samp>


Troubleshooting
---------------

Some invocation files need environment variables to be set before they
can be used.  In each case an error is reported that a particular file
cannot be found.  In many cases the problem is that the user set the
environment variable to the directory, but did not include a trailing
subdirectory separator slash at the end of the string.

When attempting to execute the Java runtime environment or the Windows
.exe files, typical messages when the program cannot be found on the
execution path are as follows:

 - Bad command or file name
 - The name specified is not recognized as an...

To determine the path, one can enter the following to see the directories:

  path

To change the path for the current command line window, enter:

  path=%path%;new-drive-and-directory-here

Note that entering this command on the command line will only change the
path for command line box being used.  To make the change permanent, one
must change the appropriate startup files for your environment.

Note that the path command does not work well when using the directory
named "Program Files" because of the embedded space.  The hidden
equivalent to this is "progra~1", so you must use "c:\progra~1\..."
with the remainder as required.

===============
$Id: book-readme.txt,v 1.7 2011/02/11 01:37:03 admin Exp $
