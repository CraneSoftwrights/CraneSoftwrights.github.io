# echo Checking $2 with $1...
CRANEPATH=`echo $0 | sed s,[^/]*$,, | sed s,^$,./,`

# echo args: $1 $2 $3 $4

if [ "$2" != "" ] && [ "$3" = "" ]
then

echo Validating structure and lexical content using UBL 2.0 $1...
sh ${CRANEPATH}w3cschema.sh ${CRANEPATH}../artefacts/os-UBL-2.0/xsd/maindoc/UBL-$1-2.0.xsd $2

if [ "$?" = "0" ]
then

echo Validating code list values...
sh ${CRANEPATH}xslt.sh $2 ${CRANEPATH}../artefacts/os-UBL-2.0/val/defaultCodeList.xsl /dev/null

if [ "$?" = "0" ]
then

echo Validation succeeded with no errors.

else

echo Validation failed with errors.

fi

fi

else

echo Needs exactly two arguments:  documentModel instance

fi
CRANEPATH=
echo
