# echo Checking $2 with $1...
CRANEPATH=`echo $0 | sed s,[^/]*$,, | sed s,^$,./,`

# echo args: $1 $2 $3 $4

if [[ "$2" != "" || "$3" == "" ]]
then

# echo Args okay

if [[ -a $2 ]]
then

# echo Instance found

# echo Looking for models:
# echo $1
# echo ${CRANEPATH}../artefacts/os-UBL-2.0/xsd/maindoc/UBL-$1-2.0.xsd

if [[ -a $1  || -a ${CRANEPATH}../artefacts/os-UBL-2.0/xsd/maindoc/UBL-$1-2.0.xsd ]]
then

# echo UBL model found

if [[ -a $1 ]]
then
echo Validating structure and lexical content using $1...
sh ${CRANEPATH}w3cschema.sh $1 $2
else
echo Validating structure and lexical content using UBL 2.0 $1...
sh ${CRANEPATH}w3cschema.sh ${CRANEPATH}../artefacts/os-UBL-2.0/xsd/maindoc/UBL-$1-2.0.xsd $2
fi

if (( $? == 0 ))
then

echo Validating code list values...
sh ${CRANEPATH}xslt.sh $2 ${CRANEPATH}../artefacts/os-UBL-2.0/val/defaultCodeList.xsl /dev/null

if (( $? == 0 ))
then

echo Validation succeeded with no errors.

else

echo Validation failed with errors.

fi

fi

else

echo Neither model can be found: $1 nor UBL-$1-2.0.xsd

fi

else

echo Instance cannot be found: $2

fi

else

echo Needs exactly two arguments:  documentModel instance

fi
CRANEPATH=
echo
