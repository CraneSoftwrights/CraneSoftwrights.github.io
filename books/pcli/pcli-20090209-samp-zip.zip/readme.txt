Practical Code List Implementation - readme.txt
==================================

Overview:
--------

Step 1: - determine the subdirectory in which the sample files will be placed

Step 2: - unpack the sample files

Note to non-Windows users:
 - the compressed package of exercise files will successfully unzip, though
   the included non-Windows invocation files do not have the execution
   permission bit set (such files are distinguished by having no extension)
   invocation arguments for Saxon

Trouble-shooting guidelines are included at the end of this document.


Unpacking the sample files
--------------------------

One self-extracting executable contains all of the sample files which
can be stored in any directory on the system you choose.

The sample files can be placed in any subdirectory you wish (it is
recommended to create a new subdirectory) and are extracted by
running the command:

  pclifile-exe.exe

or by unzipping the following file preserving the subdirectories:

  pclifile-zip.zip

A typical response for the target directory would be something like:

  c:\pcli

When the sample files are installed the following subdirectories are
created:

  artefacts - UBL, CVA and Crane artefacts
            - note that only a subset of the UBL 2.0 delivery is
              included, necessary only for the samples to be run
  prog      - invocation batch files for processors
  samp      - sample files

The use of the Java runtime
---------------------------

To test the presence of a Java runtime on the path, witness the
following result at the command line:

  C:\pcli>java
  Usage: java [-options] class [args...]
			 (to execute a class)
	 or  java -jar [-options] jarfile [args...]
			 (to execute a jar file)

If the Java runtime is not on the path, you will see something like:

  C:\pcli>java
  The name specified is not recognized as an
  internal or external command, operable program or batch file.

  C:\pcli>java
  Bad command or file name

  C:\pcli>

The Java-based invocation files rely on the Java runtime environment
named "java.exe" being on the system path.  If this is not the case,
you can execute a command similar to the following:

  path=%path%;C:\java-directory-name-here\bin


Using a non-Windows environment
-------------------------------

The Saxon JAR self-extracting executable noted above can be opened as 
a standard ZIP file and contains a single JAR file.

The Saxon invocation is as follows:

  java -cp saxon.jar -o {outputResultTree} {inputXML} {inputXSLT}

Prototype invocation files are found in prog/xslt and exercise 
invocation files are included (though the execution bit on these files 
is not set when unzipped).  There are environment variables
in the prototype invocation files you can set to your installation
directories.


Testing the installation of the sample files
--------------------------------------------

In the following, the "transport" sample is run from the transport
directory.


Windows:

C:\>cd \pcli\samp\transport
        
C:\pcli\samp\transport>transport
:: Validate constraints against the CVAUG document model:============
:: w3cschema ContextValueAssociation.xsd status-constraints.cva
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.270) with no errors and no warnings.
:: Convert constraints into a Schematron component:===================
:: xslt status-constraints.cva Crane-UBL-genericode2Schematron.xsl status-constraints.sch
:: Return: 0
:: Assemble Schematron components into a complete schema:=============
:: xslt status-codes.sch iso_schematron_assembly.xsl status-codes-runtime.sch
:: Return: 0
:: Convert Schematron schema into XSLT:===============================
:: xslt status-codes-runtime.sch Message-Schematron-terminator.xsl status-codes-runtime.xsl
:: Return: 0
:: Validate and check constraints on message-good1.xml:===============
:: w3cschema UBL-TransportationStatus-2.0.xsd message-good1.xml
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.912) with no errors and no warnings.
:: xslt message-good1.xml status-codes-runtime.xsl nul
:: Return: 0
:: Validate and check constraints on message-good2.xml:===============
:: w3cschema UBL-TransportationStatus-2.0.xsd message-good2.xml
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.941) with no errors and no warnings.
:: xslt message-good2.xml status-codes-runtime.xsl nul
:: Return: 0
:: Validate and check constraints on message-bad.xml:=================
:: w3cschema UBL-TransportationStatus-2.0.xsd message-bad.xml
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.921) with no errors and no warnings.
:: xslt message-bad.xml status-codes-runtime.xsl nul
Value supplied '999' is unacceptable for values identified by 'UBLcodes-restricted extra-codes' in the context 'cbc:ConditionCode': /TransportationStatus/cac:TransportEvent[2]/cac:CurrentStatus[1]/cbc:ConditionCode[1]

Processing terminated by xsl:message at line 151
:: Return: 1

C:\pcli\samp\transport>



Linux:

[pcli]$ cd samp/transport
[transport]$ sh transport.sh
:: Validate constraints against the CVAUG document model:============
:: w3cschema ContextValueAssociation.xsd status-constraints.cva
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.260) with no errors and no warnings.
:: Convert constraints into a Schematron component:===================
:: xslt.sh status-constraints.cva Crane-UBL-genericode2Schematron.xsl status-constraints.sch
:: Return: 0
:: Assemble Schematron components into a complete schema:=============
:: xslt.sh status-codes.sch iso_schematron_assembly.xsl status-codes-runtime.sch
:: Return: 0
:: Convert Schematron schema into XSLT:===============================
:: xslt.sh status-codes-runtime.sch Message-Schematron-terminator.xsl status-codes-runtime.xsl
:: Return: 0
:: Validate and check constraints on message-good1.xml:===============
:: w3cschema UBL-TransportationStatus-2.0.xsd message-good1.xml
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.972) with no errors and no warnings.
:: xslt.sh message-good1.xml status-codes-runtime.xsl nul
:: Return: 0
:: Validate and check constraints on message-good2.xml:===============
:: w3cschema UBL-TransportationStatus-2.0.xsd message-good2.xml
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.931) with no errors and no warnings.
:: xslt.sh message-good2.xml status-codes-runtime.xsl nul
:: Return: 0
:: Validate and check constraints on message-bad.xml:=================
:: w3cschema UBL-TransportationStatus-2.0.xsd message-bad.xml
:: Return: 0
Attempting validating, namespace-aware parse
Parse succeeded (0.921) with no errors and no warnings.
:: xslt.sh message-bad.xml status-codes-runtime.xsl nul
Value supplied '999' is unacceptable for values identified by 'UBLcodes-restricted extra-codes' in the context 'cbc:ConditionCode': /TransportationStatus/cac:TransportEvent[2]/cac:CurrentStatus[1]/cbc:ConditionCode[1]

Processing terminated by xsl:message at line 151
:: Return: 1
[transport]$



Troubleshooting
---------------

Some users have reported problems unzipping files until they associate
the "zip" file extension with the WinZip application, after which they
don't have the problems they were experiencing.

Some invocation files need environment variables to be set before they
can be used.  In each case an error is reported that a particular file
cannot be found.  In many cases the problem is that the user set the
environment variable to the directory, but did not include a trailing
subdirectory separator slash at the end of the string.

When attempting to execute the Java runtime environment or the Windows
.exe files, typical messages when the program cannot be found on the
execution path are as follows:

 - Bad command or file name
 - The name specified is not recognized as an...

To determine the path, one can enter the following to see the directories:

  path

To change the path for the current command line window, enter:

  path=%path%;new-drive-and-directory-here

Note that entering this command on the command line will only change the
path for command line box being used.  To make the change permanent, one
must change the appropriate startup files for your environment.

Note that the path command does not work well when using the directory
named "Program Files" because of the embedded space.  The hidden
equivalent to this is "progra~1", so you must use "c:\progra~1\..."
with the remainder as required.

===============
$Id: book-readme.txt,v 1.1 2009/02/09 18:04:18 gkholman Exp $
