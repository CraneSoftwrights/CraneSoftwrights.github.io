echo :: Validate constraints against the CVAUG document model:============
echo :: w3cschema ContextValueAssociation.xsd status-constraints.cva
sh ../../prog/w3cschema.sh ../../artefacts/CVAUG/xsd/ContextValueAssociation.xsd status-constraints.cva 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt

echo :: Convert constraints into a Schematron component:===================
echo :: xslt.sh status-constraints.cva Crane-UBL-genericode2Schematron.xsl status-constraints.sch
sh ../../prog/xslt.sh status-constraints.cva ../../artefacts/Crane-artefacts/Crane-CVA2sch/utility/Crane-UBL-genericode2Schematron.xsl status-constraints.sch 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt

echo :: Assemble Schematron components into a complete schema:=============
echo :: xslt.sh status-codes.sch iso_schematron_assembly.xsl status-codes-runtime.sch
sh ../../prog/xslt.sh status-codes.sch ../../artefacts/Crane-artefacts/Crane-CVA2sch/utility/iso_schematron_assembly.xsl status-codes-runtime.sch 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt

echo :: Convert Schematron schema into XSLT:===============================
echo :: xslt.sh status-codes-runtime.sch Message-Schematron-terminator.xsl status-codes-runtime.xsl
sh ../../prog/xslt.sh status-codes-runtime.sch ../../artefacts/Crane-artefacts/Crane-CVA2sch/utility/Message-Schematron-terminator.xsl status-codes-runtime.xsl 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt

echo :: Validate and check constraints on message-good1.xml:===============
echo :: w3cschema UBL-TransportationStatus-2.0.xsd message-good1.xml
sh ../../prog/w3cschema.sh ../../artefacts/os-UBL-2.0/xsd/maindoc/UBL-TransportationStatus-2.0.xsd message-good1.xml 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt
echo :: xslt.sh message-good1.xml status-codes-runtime.xsl nul
sh ../../prog/xslt.sh message-good1.xml status-codes-runtime.xsl nul 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt

echo :: Validate and check constraints on message-good2.xml:===============
echo :: w3cschema UBL-TransportationStatus-2.0.xsd message-good2.xml
sh ../../prog/w3cschema.sh ../../artefacts/os-UBL-2.0/xsd/maindoc/UBL-TransportationStatus-2.0.xsd message-good2.xml 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt
echo :: xslt.sh message-good2.xml status-codes-runtime.xsl nul
sh ../../prog/xslt.sh message-good2.xml status-codes-runtime.xsl nul 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt

echo :: Validate and check constraints on message-bad.xml:=================
echo :: w3cschema UBL-TransportationStatus-2.0.xsd message-bad.xml
sh ../../prog/w3cschema.sh ../../artefacts/os-UBL-2.0/xsd/maindoc/UBL-TransportationStatus-2.0.xsd message-bad.xml 2>&1 >test-constraints.txt
echo :: Return: $?
cat test-constraints.txt
echo :: xslt.sh message-bad.xml status-codes-runtime.xsl nul
sh ../../prog/xslt.sh message-bad.xml status-codes-runtime.xsl nul 2>&1 >test-constraints.txt
echo :: Return: $?
